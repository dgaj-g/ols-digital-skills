﻿namespace BikeShop
{
    // Who is signed in.  Set once by frmLogin, read by any form that needs to
    // record who did something.
    public static class Session
    {
        public static int StaffID { get; private set; }
        public static string FullName { get; private set; }
        public static string Role { get; private set; }

        public static bool IsSignedIn
        {
            get { return StaffID > 0; }
        }

        public static bool IsManager
        {
            get { return Role == "Manager"; }
        }

        public static void SignIn(int staffID, string fullName, string role)
        {
            StaffID = staffID;
            FullName = fullName;
            Role = role;
        }

        public static void SignOut()
        {
            StaffID = 0;
            FullName = null;
            Role = null;
        }
    }
}
