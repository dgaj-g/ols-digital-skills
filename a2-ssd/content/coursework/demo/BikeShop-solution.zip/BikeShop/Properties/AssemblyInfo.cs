﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("BikeShop")]
[assembly: AssemblyDescription("Towpath Cycles workshop and hire system")]
[assembly: AssemblyProduct("BikeShop")]
[assembly: ComVisible(false)]
[assembly: Guid("5b2a9c1e-7d3f-4e8a-9b6c-2f1d0e3a4b5c")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
