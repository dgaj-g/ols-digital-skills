﻿namespace BikeShop.Forms
{
    partial class frmBikes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblShow = new System.Windows.Forms.Label();
            this.cboFilter = new System.Windows.Forms.ComboBox();
            this.lblCustomer = new System.Windows.Forms.Label();
            this.cboCustomer = new System.Windows.Forms.ComboBox();
            this.dgvBikes = new System.Windows.Forms.DataGridView();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnReserve = new System.Windows.Forms.Button();
            this.btnUnreserve = new System.Windows.Forms.Button();
            this.btnSell = new System.Windows.Forms.Button();
            this.btnRepair = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvBikes)).BeginInit();
            this.SuspendLayout();
            // 
            // lblShow
            // 
            this.lblShow.AutoSize = true;
            this.lblShow.Location = new System.Drawing.Point(16, 18);
            this.lblShow.Name = "lblShow";
            this.lblShow.Size = new System.Drawing.Size(38, 19);
            this.lblShow.TabIndex = 0;
            this.lblShow.Text = "Show";
            // 
            // cboFilter
            // 
            this.cboFilter.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboFilter.Items.AddRange(new object[] {
            "All bikes",
            "For sale",
            "Hire fleet"});
            this.cboFilter.Location = new System.Drawing.Point(64, 15);
            this.cboFilter.Name = "cboFilter";
            this.cboFilter.Size = new System.Drawing.Size(160, 25);
            this.cboFilter.TabIndex = 1;
            this.cboFilter.SelectedIndexChanged += new System.EventHandler(this.cboFilter_SelectedIndexChanged);
            // 
            // lblCustomer
            // 
            this.lblCustomer.AutoSize = true;
            this.lblCustomer.Location = new System.Drawing.Point(260, 18);
            this.lblCustomer.Name = "lblCustomer";
            this.lblCustomer.Size = new System.Drawing.Size(243, 19);
            this.lblCustomer.TabIndex = 2;
            this.lblCustomer.Text = "Customer (for Reserve and Sell)";
            // 
            // cboCustomer
            // 
            this.cboCustomer.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboCustomer.Location = new System.Drawing.Point(500, 15);
            this.cboCustomer.Name = "cboCustomer";
            this.cboCustomer.Size = new System.Drawing.Size(280, 25);
            this.cboCustomer.TabIndex = 3;
            // 
            // dgvBikes
            // 
            this.dgvBikes.AllowUserToAddRows = false;
            this.dgvBikes.AllowUserToDeleteRows = false;
            this.dgvBikes.AllowUserToResizeRows = false;
            this.dgvBikes.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvBikes.BackgroundColor = System.Drawing.Color.White;
            this.dgvBikes.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvBikes.Location = new System.Drawing.Point(16, 52);
            this.dgvBikes.MultiSelect = false;
            this.dgvBikes.Name = "dgvBikes";
            this.dgvBikes.ReadOnly = true;
            this.dgvBikes.RowHeadersVisible = false;
            this.dgvBikes.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvBikes.Size = new System.Drawing.Size(968, 480);
            this.dgvBikes.TabIndex = 4;
            this.dgvBikes.SelectionChanged += new System.EventHandler(this.dgvBikes_SelectionChanged);
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(16, 552);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(110, 32);
            this.btnAdd.TabIndex = 5;
            this.btnAdd.Text = "Add bike";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnReserve
            // 
            this.btnReserve.Enabled = false;
            this.btnReserve.Location = new System.Drawing.Point(134, 552);
            this.btnReserve.Name = "btnReserve";
            this.btnReserve.Size = new System.Drawing.Size(100, 32);
            this.btnReserve.TabIndex = 6;
            this.btnReserve.Text = "Reserve";
            this.btnReserve.UseVisualStyleBackColor = true;
            this.btnReserve.Click += new System.EventHandler(this.btnReserve_Click);
            // 
            // btnUnreserve
            // 
            this.btnUnreserve.Enabled = false;
            this.btnUnreserve.Location = new System.Drawing.Point(242, 552);
            this.btnUnreserve.Name = "btnUnreserve";
            this.btnUnreserve.Size = new System.Drawing.Size(110, 32);
            this.btnUnreserve.TabIndex = 7;
            this.btnUnreserve.Text = "Un-reserve";
            this.btnUnreserve.UseVisualStyleBackColor = true;
            this.btnUnreserve.Click += new System.EventHandler(this.btnUnreserve_Click);
            // 
            // btnSell
            // 
            this.btnSell.Enabled = false;
            this.btnSell.Location = new System.Drawing.Point(360, 552);
            this.btnSell.Name = "btnSell";
            this.btnSell.Size = new System.Drawing.Size(100, 32);
            this.btnSell.TabIndex = 8;
            this.btnSell.Text = "Sell";
            this.btnSell.UseVisualStyleBackColor = true;
            this.btnSell.Click += new System.EventHandler(this.btnSell_Click);
            // 
            // btnRepair
            // 
            this.btnRepair.Enabled = false;
            this.btnRepair.Location = new System.Drawing.Point(468, 552);
            this.btnRepair.Name = "btnRepair";
            this.btnRepair.Size = new System.Drawing.Size(150, 32);
            this.btnRepair.TabIndex = 9;
            this.btnRepair.Text = "Send for repair";
            this.btnRepair.UseVisualStyleBackColor = true;
            this.btnRepair.Click += new System.EventHandler(this.btnRepair_Click);
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(884, 552);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(100, 32);
            this.btnClose.TabIndex = 10;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // frmBikes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.ClientSize = new System.Drawing.Size(1000, 600);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnRepair);
            this.Controls.Add(this.btnSell);
            this.Controls.Add(this.btnUnreserve);
            this.Controls.Add(this.btnReserve);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.dgvBikes);
            this.Controls.Add(this.cboCustomer);
            this.Controls.Add(this.lblCustomer);
            this.Controls.Add(this.cboFilter);
            this.Controls.Add(this.lblShow);
            this.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "frmBikes";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Bikes";
            this.Load += new System.EventHandler(this.frmBikes_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvBikes)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblShow;
        private System.Windows.Forms.ComboBox cboFilter;
        private System.Windows.Forms.Label lblCustomer;
        private System.Windows.Forms.ComboBox cboCustomer;
        private System.Windows.Forms.DataGridView dgvBikes;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnReserve;
        private System.Windows.Forms.Button btnUnreserve;
        private System.Windows.Forms.Button btnSell;
        private System.Windows.Forms.Button btnRepair;
        private System.Windows.Forms.Button btnClose;
    }
}
