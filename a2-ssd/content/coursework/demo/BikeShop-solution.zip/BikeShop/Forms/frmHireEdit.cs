﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using BikeShop.Data;
using BikeShop.Models;

namespace BikeShop.Forms
{
    public partial class frmHireEdit : Form
    {
        public frmHireEdit()
        {
            InitializeComponent();
        }

        private void frmHireEdit_Load(object sender, EventArgs e)
        {
            cboCustomer.DisplayMember = "FullName";
            cboCustomer.ValueMember = "CustomerID";
            cboCustomer.DataSource = CustomerData.Search("");

            dtpStart.Value = DateTime.Today.AddDays(1);
            dtpEnd.Value = DateTime.Today.AddDays(2);
            RefreshBikes();
        }

        #region FreeBikes
        // Asks the database which bikes are free for the whole of the chosen
        // dates.
        private void RefreshBikes()
        {
            cboBike.DisplayMember = "Display";      // "Trek FX 2 · M · Blue"
            cboBike.ValueMember = "BikeID";
            cboBike.DataSource = BikeData.GetAvailableForHire(dtpStart.Value,
                dtpEnd.Value);
            ShowCost();
        }

        private void dtpStart_ValueChanged(object sender, EventArgs e)
        {
            // The return day must come after the start day: push it along if it
            // does not.
            if (dtpEnd.Value.Date <= dtpStart.Value.Date)
            {
                dtpEnd.Value = dtpStart.Value.Date.AddDays(1);
            }
            RefreshBikes();
        }

        private void dtpEnd_ValueChanged(object sender, EventArgs e)
        {
            RefreshBikes();
        }

        private void cboBike_SelectedIndexChanged(object sender, EventArgs e)
        {
            ShowCost();
        }
        #endregion

        #region ShowCost
        // Works out the price line as the choices change: days × daily rate,
        // and the smallest deposit (20%).
        private void ShowCost()
        {
            if (cboBike.SelectedItem == null)
            {
                lblCost.Text =
                    "No bike is free for those dates. Try other dates.";
                btnBook.Enabled = false;
                return;
            }

            // the row behind the chosen item
            DataRowView bike = (DataRowView)cboBike.SelectedItem;
            int days = (dtpEnd.Value.Date - dtpStart.Value.Date).Days;
            decimal rate = (decimal)bike["DailyRate"];
            decimal total = days * rate;
            decimal smallestDeposit = Math.Round(total * 0.2m, 2);

            string dayWord = "days";
            if (days == 1)
            {
                dayWord = "day";
            }
            lblCost.Text = days + " " + dayWord + " × £" + rate.ToString("0.00")
                + " = £" + total.ToString("0.00")
                + " · deposit at least £" + smallestDeposit.ToString("0.00");
            nudDeposit.Value = Math.Min(smallestDeposit, nudDeposit.Maximum);
            btnBook.Enabled = true;
        }
        #endregion

        #region Book
        private void btnBook_Click(object sender, EventArgs e)
        {
            // Check what was chosen, one problem at a time: show the first and
            // put the cursor there.
            // The deposit needs no check for being negative: its box does not
            // go below 0.
            if (cboCustomer.SelectedValue == null)
            {
                Msg.Problem("Choose the customer.");
                cboCustomer.Focus();
                return;
            }
            if (dtpEnd.Value.Date <= dtpStart.Value.Date)
            {
                Msg.Problem("The return date must be after the start date.");
                dtpEnd.Focus();
                return;
            }
            if (cboBike.SelectedValue == null)
            {
                Msg.Problem("Choose a bike. If none is free, try other dates.");
                cboBike.Focus();
                return;
            }

            Hire hire = new Hire();
            hire.CustomerID = (int)cboCustomer.SelectedValue;
            hire.BikeID = (int)cboBike.SelectedValue;
            hire.StartDate = dtpStart.Value.Date;
            hire.EndDate = dtpEnd.Value.Date;
            hire.DepositPaid = nudDeposit.Value;
            hire.BookedByStaffID = Session.StaffID;

            // The database checks the dates, the deposit and that the bike is
            // free.
            string message = HireData.Add(hire);
            if (message != "")
            {
                Msg.Problem(message);
                // the list may have changed since it was filled
                RefreshBikes();
                return;
            }
            DialogResult = DialogResult.OK;
        }
        #endregion
    }
}
