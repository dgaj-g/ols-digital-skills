﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using BikeShop.Data;
using BikeShop.Models;

namespace BikeShop.Forms
{
    public partial class frmCustomers : Form
    {
        public frmCustomers()
        {
            InitializeComponent();
        }

        private void frmCustomers_Load(object sender, EventArgs e)
        {
            LoadCustomers();
        }

        #region LoadCustomers
        // Fills the grid from the database.  Called when the form opens, when
        // the search text changes,
        // and after every add, edit or delete, so the grid always shows what
        // the database holds.
        private void LoadCustomers()
        {
            dgvCustomers.DataSource =
                CustomerData.Search(txtSearch.Text.Trim());
            // hide the ID, give the headers plain words
            Grid.Tidy(dgvCustomers, "CustomerID");
        }
        #endregion

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            LoadCustomers();
        }

        #region Selection
        // Edit and Delete only make sense once a row is picked.
        private void dgvCustomers_SelectionChanged(object sender, EventArgs e)
        {
            bool picked = dgvCustomers.SelectedRows.Count > 0;
            btnEdit.Enabled = picked;
            btnDelete.Enabled = picked;
            ShowBookings();
        }

        // The lower grid shows the picked customer's bookings: two tables on
        // one screen.
        private void ShowBookings()
        {
            if (dgvCustomers.SelectedRows.Count == 0)
            {
                dgvBookings.DataSource = null;
                return;
            }

            dgvBookings.DataSource =
                AppointmentData.GetForCustomer(Grid.SelectedID(dgvCustomers,
                "CustomerID"));
            Grid.Tidy(dgvBookings, "AppointmentID");
        }
        #endregion

        #region AddEditDelete
        private void btnAdd_Click(object sender, EventArgs e)
        {
            // 0 means "a new customer"
            frmCustomerEdit edit = new frmCustomerEdit(0);
            if (edit.ShowDialog(this) == DialogResult.OK)
            {
                LoadCustomers();
            }
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            frmCustomerEdit edit =
                new frmCustomerEdit(Grid.SelectedID(dgvCustomers,
                "CustomerID"));
            if (edit.ShowDialog(this) == DialogResult.OK)
            {
                LoadCustomers();
            }
        }

        private void dgvCustomers_CellDoubleClick(object sender,
            DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                btnEdit_Click(sender, e);
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            string name = Grid.SelectedText(dgvCustomers, "FullName");
            if (!Msg.Ask("Delete " + name + "? This cannot be undone."))
            {
                return;
            }

            string message =
                CustomerData.Delete(Grid.SelectedID(dgvCustomers,
                "CustomerID"));
            if (message != "")
            {
                // the database refuses when the customer has bookings or sales,
                // and says so
                Msg.Problem(message);
                return;
            }
            LoadCustomers();
        }
        #endregion

        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
