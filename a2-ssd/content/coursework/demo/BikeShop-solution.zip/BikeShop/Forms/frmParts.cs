﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using BikeShop.Data;
using BikeShop.Models;

namespace BikeShop.Forms
{
    public partial class frmParts : Form
    {
        // false = every part; true = only the parts at or below their reorder
        // level
        private bool reorderOnly;

        public frmParts()
        {
            InitializeComponent();
        }

        private void frmParts_Load(object sender, EventArgs e)
        {
            LoadParts();
            LoadOrders();
        }

        #region LoadParts
        private void LoadParts()
        {
            if (reorderOnly)
            {
                dgvParts.DataSource = PartData.GetReorderList();
                btnReorderList.Text = "Show all parts";
            }
            else
            {
                dgvParts.DataSource = PartData.GetAll();
                btnReorderList.Text = "Reorder list";
            }
            Grid.Tidy(dgvParts, "PartID", "SupplierID");
        }

        // The grid raises this when it has finished filling: the moment to tint
        // the parts that are low on stock.
        private void dgvParts_DataBindingComplete(object sender,
            DataGridViewBindingCompleteEventArgs e)
        {
            if (reorderOnly)
            {
                // every part on the reorder list is low, so only the full list
                // is tinted
                return;
            }

            foreach (DataGridViewRow row in dgvParts.Rows)
            {
                int inStock = Convert.ToInt32(row.Cells["QtyInStock"].Value);
                int reorderLevel =
                    Convert.ToInt32(row.Cells["ReorderLevel"].Value);
                if (inStock <= reorderLevel)
                {
                    row.DefaultCellStyle.BackColor = Color.MistyRose;
                }
                else
                {
                    row.DefaultCellStyle.BackColor = Color.White;
                }
            }
        }

        private void btnReorderList_Click(object sender, EventArgs e)
        {
            reorderOnly = !reorderOnly;
            LoadParts();
        }
        #endregion

        #region LoadOrders
        private void LoadOrders()
        {
            dgvOrders.DataSource = PartOrderData.GetOpen();
            Grid.Tidy(dgvOrders, "PartOrderID");
        }
        #endregion

        #region Selection
        private void dgvParts_SelectionChanged(object sender, EventArgs e)
        {
            bool picked = dgvParts.SelectedRows.Count > 0;
            // the reorder list has no cost columns to edit from
            btnEditPart.Enabled = picked && !reorderOnly;
            btnSell.Enabled = picked;
            btnOrder.Enabled = picked;
        }

        private void dgvOrders_SelectionChanged(object sender, EventArgs e)
        {
            bool picked = dgvOrders.SelectedRows.Count > 0;
            btnReceive.Enabled = picked;
            btnCancelOrder.Enabled = picked;
        }
        #endregion

        #region PartActions
        private void btnAddPart_Click(object sender, EventArgs e)
        {
            frmPartEdit add = new frmPartEdit();
            if (add.ShowDialog(this) == DialogResult.OK)
            {
                LoadParts();
            }
        }

        private void btnEditPart_Click(object sender, EventArgs e)
        {
            // the row behind the picked line
            DataRowView row =
                (DataRowView)dgvParts.SelectedRows[0].DataBoundItem;
            frmPartEdit edit = new frmPartEdit(row.Row);
            if (edit.ShowDialog(this) == DialogResult.OK)
            {
                LoadParts();
            }
        }

        private void btnSell_Click(object sender, EventArgs e)
        {
            DataGridViewRow row = dgvParts.SelectedRows[0];
            int inStock = Convert.ToInt32(row.Cells["QtyInStock"].Value);
            int partID = Grid.SelectedID(dgvParts, "PartID");
            string name = Grid.SelectedText(dgvParts, "Name");
            frmPartSell sell = new frmPartSell(partID, name, inStock);
            if (sell.ShowDialog(this) == DialogResult.OK)
            {
                LoadParts();
            }
        }

        private void btnOrder_Click(object sender, EventArgs e)
        {
            DataGridViewRow row = dgvParts.SelectedRows[0];
            int reorderQty = Convert.ToInt32(row.Cells["ReorderQty"].Value);
            int partID = Grid.SelectedID(dgvParts, "PartID");
            string name = Grid.SelectedText(dgvParts, "Name");
            frmPartOrderPlace place =
                new frmPartOrderPlace(partID, name, reorderQty);
            if (place.ShowDialog(this) == DialogResult.OK)
            {
                LoadOrders();
            }
        }
        #endregion

        #region OrderActions
        private void btnReceive_Click(object sender, EventArgs e)
        {
            string summary = Grid.SelectedText(dgvOrders, "PartCode") + " · "
                + Grid.SelectedText(dgvOrders, "Part") + " from "
                + Grid.SelectedText(dgvOrders, "Supplier");
            DataGridViewRow row = dgvOrders.SelectedRows[0];
            int ordered = Convert.ToInt32(row.Cells["QtyOrdered"].Value);
            int orderID = Grid.SelectedID(dgvOrders, "PartOrderID");
            frmPartOrderReceive receive =
                new frmPartOrderReceive(orderID, summary, ordered);
            if (receive.ShowDialog(this) == DialogResult.OK)
            {
                LoadOrders();
                // the delivery has added to the stock figures
                LoadParts();
            }
        }

        private void btnCancelOrder_Click(object sender, EventArgs e)
        {
            if (!Msg.Ask("Cancel the order for "
                + Grid.SelectedText(dgvOrders, "Part") + "?"))
            {
                return;
            }

            string message =
                PartOrderData.Cancel(Grid.SelectedID(dgvOrders, "PartOrderID"));
            if (message != "")
            {
                Msg.Problem(message);
                return;
            }
            LoadOrders();
        }
        #endregion

        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
