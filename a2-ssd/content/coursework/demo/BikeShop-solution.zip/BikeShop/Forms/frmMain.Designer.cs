﻿namespace BikeShop.Forms
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblWelcome = new System.Windows.Forms.Label();
            this.lblSignedIn = new System.Windows.Forms.Label();
            this.btnDiary = new System.Windows.Forms.Button();
            this.btnCustomers = new System.Windows.Forms.Button();
            this.btnHires = new System.Windows.Forms.Button();
            this.btnBikes = new System.Windows.Forms.Button();
            this.btnParts = new System.Windows.Forms.Button();
            this.btnReports = new System.Windows.Forms.Button();
            this.btnSignOut = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblWelcome
            // 
            this.lblWelcome.AutoSize = true;
            this.lblWelcome.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWelcome.Location = new System.Drawing.Point(24, 18);
            this.lblWelcome.Name = "lblWelcome";
            this.lblWelcome.Size = new System.Drawing.Size(240, 37);
            this.lblWelcome.TabIndex = 0;
            this.lblWelcome.Text = "Towpath Cycles";
            // 
            // lblSignedIn
            // 
            this.lblSignedIn.AutoSize = true;
            this.lblSignedIn.Location = new System.Drawing.Point(24, 58);
            this.lblSignedIn.Name = "lblSignedIn";
            this.lblSignedIn.Size = new System.Drawing.Size(91, 19);
            this.lblSignedIn.TabIndex = 1;
            this.lblSignedIn.Text = "Signed in: ";
            // 
            // btnDiary
            // 
            this.btnDiary.Location = new System.Drawing.Point(24, 100);
            this.btnDiary.Name = "btnDiary";
            this.btnDiary.Size = new System.Drawing.Size(280, 80);
            this.btnDiary.TabIndex = 2;
            this.btnDiary.Text = "Workshop diary";
            this.btnDiary.UseVisualStyleBackColor = true;
            this.btnDiary.Click += new System.EventHandler(this.btnDiary_Click);
            // 
            // btnCustomers
            // 
            this.btnCustomers.Location = new System.Drawing.Point(336, 100);
            this.btnCustomers.Name = "btnCustomers";
            this.btnCustomers.Size = new System.Drawing.Size(280, 80);
            this.btnCustomers.TabIndex = 3;
            this.btnCustomers.Text = "Customers";
            this.btnCustomers.UseVisualStyleBackColor = true;
            this.btnCustomers.Click += new System.EventHandler(this.btnCustomers_Click);
            // 
            // btnHires
            // 
            this.btnHires.Location = new System.Drawing.Point(24, 196);
            this.btnHires.Name = "btnHires";
            this.btnHires.Size = new System.Drawing.Size(280, 80);
            this.btnHires.TabIndex = 4;
            this.btnHires.Text = "Bike hire";
            this.btnHires.UseVisualStyleBackColor = true;
            this.btnHires.Click += new System.EventHandler(this.btnHires_Click);
            // 
            // btnBikes
            // 
            this.btnBikes.Location = new System.Drawing.Point(336, 196);
            this.btnBikes.Name = "btnBikes";
            this.btnBikes.Size = new System.Drawing.Size(280, 80);
            this.btnBikes.TabIndex = 5;
            this.btnBikes.Text = "Bikes for sale and hire";
            this.btnBikes.UseVisualStyleBackColor = true;
            this.btnBikes.Click += new System.EventHandler(this.btnBikes_Click);
            // 
            // btnParts
            // 
            this.btnParts.Location = new System.Drawing.Point(24, 292);
            this.btnParts.Name = "btnParts";
            this.btnParts.Size = new System.Drawing.Size(280, 80);
            this.btnParts.TabIndex = 6;
            this.btnParts.Text = "Parts and stock";
            this.btnParts.UseVisualStyleBackColor = true;
            this.btnParts.Click += new System.EventHandler(this.btnParts_Click);
            // 
            // btnReports
            // 
            this.btnReports.Location = new System.Drawing.Point(336, 292);
            this.btnReports.Name = "btnReports";
            this.btnReports.Size = new System.Drawing.Size(280, 80);
            this.btnReports.TabIndex = 7;
            this.btnReports.Text = "Reports";
            this.btnReports.UseVisualStyleBackColor = true;
            this.btnReports.Click += new System.EventHandler(this.btnReports_Click);
            // 
            // btnSignOut
            // 
            this.btnSignOut.Location = new System.Drawing.Point(516, 380);
            this.btnSignOut.Name = "btnSignOut";
            this.btnSignOut.Size = new System.Drawing.Size(100, 32);
            this.btnSignOut.TabIndex = 8;
            this.btnSignOut.Text = "Sign out";
            this.btnSignOut.UseVisualStyleBackColor = true;
            this.btnSignOut.Click += new System.EventHandler(this.btnSignOut_Click);
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.ClientSize = new System.Drawing.Size(640, 420);
            this.Controls.Add(this.btnSignOut);
            this.Controls.Add(this.btnReports);
            this.Controls.Add(this.btnParts);
            this.Controls.Add(this.btnBikes);
            this.Controls.Add(this.btnHires);
            this.Controls.Add(this.btnCustomers);
            this.Controls.Add(this.btnDiary);
            this.Controls.Add(this.lblSignedIn);
            this.Controls.Add(this.lblWelcome);
            this.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "frmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Towpath Cycles";
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblWelcome;
        private System.Windows.Forms.Label lblSignedIn;
        private System.Windows.Forms.Button btnDiary;
        private System.Windows.Forms.Button btnCustomers;
        private System.Windows.Forms.Button btnHires;
        private System.Windows.Forms.Button btnBikes;
        private System.Windows.Forms.Button btnParts;
        private System.Windows.Forms.Button btnReports;
        private System.Windows.Forms.Button btnSignOut;
    }
}
