﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using BikeShop.Data;
using BikeShop.Models;

namespace BikeShop.Forms
{
    public partial class frmHires : Form
    {
        public frmHires()
        {
            InitializeComponent();
        }

        private void frmHires_Load(object sender, EventArgs e)
        {
            dtpFrom.Value = DateTime.Today.AddDays(-7);
            dtpTo.Value = DateTime.Today.AddDays(28);
            LoadHires();
        }

        #region LoadHires
        private void LoadHires()
        {
            dgvHires.DataSource = HireData.GetByDateRange(dtpFrom.Value,
                dtpTo.Value);
            Grid.Tidy(dgvHires, "HireID");
        }
        #endregion

        private void dtpFrom_ValueChanged(object sender, EventArgs e)
        {
            LoadHires();
        }

        private void dtpTo_ValueChanged(object sender, EventArgs e)
        {
            LoadHires();
        }

        #region Selection
        // Each button matches one status: Booked can be checked out or
        // cancelled; Out can be returned.
        private void dgvHires_SelectionChanged(object sender, EventArgs e)
        {
            string status = "";
            if (dgvHires.SelectedRows.Count > 0)
            {
                status = Grid.SelectedText(dgvHires, "Status");
            }
            btnCheckOut.Enabled = status == "Booked";
            btnCancelHire.Enabled = status == "Booked";
            btnReturn.Enabled = status == "Out";
        }
        #endregion

        #region Actions
        private void btnNew_Click(object sender, EventArgs e)
        {
            frmHireEdit hire = new frmHireEdit();
            if (hire.ShowDialog(this) == DialogResult.OK)
            {
                LoadHires();
            }
        }

        private void btnCheckOut_Click(object sender, EventArgs e)
        {
            if (!Msg.Ask("Hand the " + Grid.SelectedText(dgvHires, "Bike")
                + " to " + Grid.SelectedText(dgvHires, "Customer") + " now?"))
            {
                return;
            }

            string message =
                HireData.CheckOut(Grid.SelectedID(dgvHires, "HireID"));
            if (message != "")
            {
                Msg.Problem(message);
                return;
            }
            LoadHires();
        }

        private void btnReturn_Click(object sender, EventArgs e)
        {
            if (!Msg.Ask("Has the " + Grid.SelectedText(dgvHires, "Bike")
                + " come back?"))
            {
                return;
            }

            string message =
                HireData.Return(Grid.SelectedID(dgvHires, "HireID"));
            if (message != "")
            {
                Msg.Problem(message);
                return;
            }
            LoadHires();
        }

        private void btnCancelHire_Click(object sender, EventArgs e)
        {
            if (!Msg.Ask("Cancel this hire for "
                + Grid.SelectedText(dgvHires, "Customer")
                + "? The bike becomes free for those dates."))
            {
                return;
            }

            string message =
                HireData.Cancel(Grid.SelectedID(dgvHires, "HireID"));
            if (message != "")
            {
                Msg.Problem(message);
                return;
            }
            LoadHires();
        }
        #endregion

        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
