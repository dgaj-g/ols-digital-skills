﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using BikeShop.Data;
using BikeShop.Models;

namespace BikeShop.Forms
{
    public partial class frmCustomerEdit : Form
    {
        // 0 = adding; otherwise the customer being edited
        private readonly int customerID;

        public frmCustomerEdit(int id)
        {
            InitializeComponent();
            customerID = id;
        }

        private void frmCustomerEdit_Load(object sender, EventArgs e)
        {
            // The boxes stop typing at the length the database column holds.
            txtFirstName.MaxLength = 40;
            txtLastName.MaxLength = 40;
            txtPhone.MaxLength = 15;
            txtEmail.MaxLength = 100;

            if (customerID == 0)
            {
                Text = "Add a customer";
                return;
            }

            Text = "Edit customer";
            Customer customer = CustomerData.GetByID(customerID);
            txtFirstName.Text = customer.FirstName;
            txtLastName.Text = customer.LastName;
            txtPhone.Text = customer.Phone;
            txtEmail.Text = customer.Email;
        }

        #region Save
        private void btnSave_Click(object sender, EventArgs e)
        {
            // Check what was typed, one problem at a time: show the first and
            // put the cursor in that box.
            if (txtFirstName.Text.Trim() == "")
            {
                Msg.Problem("Type the customer's first name.");
                txtFirstName.Focus();
                return;
            }
            if (txtLastName.Text.Trim() == "")
            {
                Msg.Problem("Type the customer's last name.");
                txtLastName.Focus();
                return;
            }
            string phoneProblem = PhoneProblem(txtPhone.Text.Trim());
            if (phoneProblem != "")
            {
                Msg.Problem(phoneProblem);
                txtPhone.Focus();
                return;
            }
            string emailProblem = EmailProblem(txtEmail.Text.Trim());
            if (emailProblem != "")
            {
                Msg.Problem(emailProblem);
                txtEmail.Focus();
                return;
            }

            Customer customer = new Customer();
            customer.CustomerID = customerID;
            customer.FirstName = txtFirstName.Text.Trim();
            customer.LastName = txtLastName.Text.Trim();
            customer.Phone = txtPhone.Text.Trim();
            customer.Email = txtEmail.Text.Trim();
            if (customer.Email == "")
            {
                // nothing typed: store a NULL, not an empty piece of text
                customer.Email = null;
            }

            string message;
            if (customerID == 0)
            {
                message = CustomerData.Add(customer);
            }
            else
            {
                message = CustomerData.Update(customer);
            }
            if (message != "")
            {
                Msg.Problem(message);
                return;
            }
            // closes this form and tells the list to refresh
            DialogResult = DialogResult.OK;
        }

        // Returns "" when the phone number is fine; otherwise a sentence saying
        // what is wrong with it.
        private string PhoneProblem(string phone)
        {
            if (phone == "")
            {
                return "Type the customer's phone number.";
            }

            int digits = 0;
            foreach (char letter in phone)
            {
                if (char.IsDigit(letter))
                {
                    digits = digits + 1;
                }
                else if (letter != ' ' && letter != '+' && letter != '-')
                {
                    return "A phone number can only have digits, spaces, + " +
                        "and -.";
                }
            }
            if (digits < 10)
            {
                return "A phone number needs at least 10 digits.";
            }
            return "";
        }

        // Returns "" when the email is fine.  An email is optional, so a blank
        // box is fine too.
        private string EmailProblem(string email)
        {
            if (email == "")
            {
                return "";
            }

            int at = email.IndexOf('@');
            if (at < 1 || email.IndexOf('.', at) < at + 2
                || email.EndsWith("."))
            {
                return "An email address must look like name@example.com.";
            }
            return "";
        }
        #endregion
    }
}
