﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using BikeShop.Data;
using BikeShop.Models;

namespace BikeShop.Forms
{
    public partial class frmPartEdit : Form
    {
        // 0 = adding; otherwise the part being edited
        private readonly int partID;

        // Add a part
        public frmPartEdit()
        {
            InitializeComponent();
        }

        // Edit a part: the values come from the row the grid already holds
        public frmPartEdit(DataRow part)
        {
            InitializeComponent();
            partID = (int)part["PartID"];
            txtCode.Text = (string)part["PartCode"];
            txtName.Text = (string)part["Name"];
            nudUnitCost.Value = (decimal)part["UnitCost"];
            nudSellPrice.Value = (decimal)part["SellPrice"];
            nudReorderLevel.Value = (int)part["ReorderLevel"];
            nudReorderQty.Value = (int)part["ReorderQty"];
            // kept until the supplier list has loaded
            cboSupplier.Tag = part["SupplierID"];
        }

        private void frmPartEdit_Load(object sender, EventArgs e)
        {
            // The boxes stop typing at the length the database column holds.
            txtCode.MaxLength = 12;
            txtName.MaxLength = 60;

            cboSupplier.DisplayMember = "Name";
            cboSupplier.ValueMember = "SupplierID";
            cboSupplier.DataSource = SupplierData.GetAll();

            if (partID == 0)
            {
                Text = "Add a part";
                return;
            }

            Text = "Edit part";
            cboSupplier.SelectedValue = cboSupplier.Tag;
            // the code is the part's name on the shelf: it does not change
            txtCode.Enabled = false;
            lblStock.Text =
                "Stock changes only through sales, refunds and deliveries.";
            nudStock.Visible = false;
        }

        #region Save
        private void btnSave_Click(object sender, EventArgs e)
        {
            // Check what was typed, one problem at a time: show the first and
            // put the cursor there.
            // The number boxes need no check: none of them goes below 0, and
            // the reorder quantity starts at 1.
            if (txtCode.Text.Trim() == "")
            {
                Msg.Problem("Type the part code.");
                txtCode.Focus();
                return;
            }
            if (txtName.Text.Trim() == "")
            {
                Msg.Problem("Type the part's name.");
                txtName.Focus();
                return;
            }
            if (cboSupplier.SelectedValue == null)
            {
                Msg.Problem("Choose the part's supplier.");
                cboSupplier.Focus();
                return;
            }

            Part part = new Part();
            part.PartID = partID;
            part.PartCode = txtCode.Text.Trim().ToUpper();
            part.Name = txtName.Text.Trim();
            part.SupplierID = (int)cboSupplier.SelectedValue;
            part.UnitCost = nudUnitCost.Value;
            part.SellPrice = nudSellPrice.Value;
            part.QtyInStock = (int)nudStock.Value;
            part.ReorderLevel = (int)nudReorderLevel.Value;
            part.ReorderQty = (int)nudReorderQty.Value;

            string message;
            if (partID == 0)
            {
                message = PartData.Add(part);
            }
            else
            {
                message = PartData.Update(part);
            }
            if (message != "")
            {
                // e.g. that part code is already in use
                Msg.Problem(message);
                return;
            }
            DialogResult = DialogResult.OK;
        }
        #endregion
    }
}
