﻿namespace BikeShop.Forms
{
    partial class frmPartEdit
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblCode = new System.Windows.Forms.Label();
            this.txtCode = new System.Windows.Forms.TextBox();
            this.lblName = new System.Windows.Forms.Label();
            this.txtName = new System.Windows.Forms.TextBox();
            this.lblSupplier = new System.Windows.Forms.Label();
            this.cboSupplier = new System.Windows.Forms.ComboBox();
            this.lblUnitCost = new System.Windows.Forms.Label();
            this.nudUnitCost = new System.Windows.Forms.NumericUpDown();
            this.lblSellPrice = new System.Windows.Forms.Label();
            this.nudSellPrice = new System.Windows.Forms.NumericUpDown();
            this.lblInStock = new System.Windows.Forms.Label();
            this.nudStock = new System.Windows.Forms.NumericUpDown();
            this.lblStock = new System.Windows.Forms.Label();
            this.lblReorderLevel = new System.Windows.Forms.Label();
            this.nudReorderLevel = new System.Windows.Forms.NumericUpDown();
            this.lblReorderQty = new System.Windows.Forms.Label();
            this.nudReorderQty = new System.Windows.Forms.NumericUpDown();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.nudUnitCost)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudSellPrice)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudStock)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudReorderLevel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudReorderQty)).BeginInit();
            this.SuspendLayout();
            // 
            // lblCode
            // 
            this.lblCode.AutoSize = true;
            this.lblCode.Location = new System.Drawing.Point(20, 23);
            this.lblCode.Name = "lblCode";
            this.lblCode.Size = new System.Drawing.Size(76, 19);
            this.lblCode.TabIndex = 0;
            this.lblCode.Text = "Part code";
            // 
            // txtCode
            // 
            this.txtCode.Location = new System.Drawing.Point(160, 20);
            this.txtCode.Name = "txtCode";
            this.txtCode.Size = new System.Drawing.Size(140, 25);
            this.txtCode.TabIndex = 1;
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Location = new System.Drawing.Point(20, 63);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(38, 19);
            this.lblName.TabIndex = 2;
            this.lblName.Text = "Name";
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(160, 60);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(300, 25);
            this.txtName.TabIndex = 3;
            // 
            // lblSupplier
            // 
            this.lblSupplier.AutoSize = true;
            this.lblSupplier.Location = new System.Drawing.Point(20, 103);
            this.lblSupplier.Name = "lblSupplier";
            this.lblSupplier.Size = new System.Drawing.Size(68, 19);
            this.lblSupplier.TabIndex = 4;
            this.lblSupplier.Text = "Supplier";
            // 
            // cboSupplier
            // 
            this.cboSupplier.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboSupplier.Location = new System.Drawing.Point(160, 100);
            this.cboSupplier.Name = "cboSupplier";
            this.cboSupplier.Size = new System.Drawing.Size(300, 25);
            this.cboSupplier.TabIndex = 5;
            // 
            // lblUnitCost
            // 
            this.lblUnitCost.AutoSize = true;
            this.lblUnitCost.Location = new System.Drawing.Point(20, 143);
            this.lblUnitCost.Name = "lblUnitCost";
            this.lblUnitCost.Size = new System.Drawing.Size(91, 19);
            this.lblUnitCost.TabIndex = 6;
            this.lblUnitCost.Text = "Unit cost £";
            // 
            // nudUnitCost
            // 
            this.nudUnitCost.DecimalPlaces = 2;
            this.nudUnitCost.Location = new System.Drawing.Point(160, 140);
            this.nudUnitCost.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.nudUnitCost.Name = "nudUnitCost";
            this.nudUnitCost.Size = new System.Drawing.Size(120, 25);
            this.nudUnitCost.TabIndex = 7;
            // 
            // lblSellPrice
            // 
            this.lblSellPrice.AutoSize = true;
            this.lblSellPrice.Location = new System.Drawing.Point(20, 183);
            this.lblSellPrice.Name = "lblSellPrice";
            this.lblSellPrice.Size = new System.Drawing.Size(99, 19);
            this.lblSellPrice.TabIndex = 8;
            this.lblSellPrice.Text = "Sell price £";
            // 
            // nudSellPrice
            // 
            this.nudSellPrice.DecimalPlaces = 2;
            this.nudSellPrice.Location = new System.Drawing.Point(160, 180);
            this.nudSellPrice.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.nudSellPrice.Name = "nudSellPrice";
            this.nudSellPrice.Size = new System.Drawing.Size(120, 25);
            this.nudSellPrice.TabIndex = 9;
            // 
            // lblInStock
            // 
            this.lblInStock.AutoSize = true;
            this.lblInStock.Location = new System.Drawing.Point(20, 223);
            this.lblInStock.Name = "lblInStock";
            this.lblInStock.Size = new System.Drawing.Size(68, 19);
            this.lblInStock.TabIndex = 10;
            this.lblInStock.Text = "In stock";
            // 
            // nudStock
            // 
            this.nudStock.Location = new System.Drawing.Point(160, 220);
            this.nudStock.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.nudStock.Name = "nudStock";
            this.nudStock.Size = new System.Drawing.Size(120, 25);
            this.nudStock.TabIndex = 11;
            // 
            // lblStock
            // 
            this.lblStock.AutoSize = true;
            this.lblStock.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(92)))), ((int)(((byte)(103)))), ((int)(((byte)(116)))));
            this.lblStock.Location = new System.Drawing.Point(160, 248);
            this.lblStock.Name = "lblStock";
            this.lblStock.Size = new System.Drawing.Size(300, 19);
            this.lblStock.TabIndex = 12;
            this.lblStock.Text = "";
            // 
            // lblReorderLevel
            // 
            this.lblReorderLevel.AutoSize = true;
            this.lblReorderLevel.Location = new System.Drawing.Point(20, 283);
            this.lblReorderLevel.Name = "lblReorderLevel";
            this.lblReorderLevel.Size = new System.Drawing.Size(106, 19);
            this.lblReorderLevel.TabIndex = 13;
            this.lblReorderLevel.Text = "Reorder level";
            // 
            // nudReorderLevel
            // 
            this.nudReorderLevel.Location = new System.Drawing.Point(160, 280);
            this.nudReorderLevel.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.nudReorderLevel.Name = "nudReorderLevel";
            this.nudReorderLevel.Size = new System.Drawing.Size(120, 25);
            this.nudReorderLevel.TabIndex = 14;
            // 
            // lblReorderQty
            // 
            this.lblReorderQty.AutoSize = true;
            this.lblReorderQty.Location = new System.Drawing.Point(20, 323);
            this.lblReorderQty.Name = "lblReorderQty";
            this.lblReorderQty.Size = new System.Drawing.Size(106, 19);
            this.lblReorderQty.TabIndex = 15;
            this.lblReorderQty.Text = "Usually order";
            // 
            // nudReorderQty
            // 
            this.nudReorderQty.Location = new System.Drawing.Point(160, 320);
            this.nudReorderQty.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.nudReorderQty.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudReorderQty.Name = "nudReorderQty";
            this.nudReorderQty.Size = new System.Drawing.Size(120, 25);
            this.nudReorderQty.TabIndex = 16;
            this.nudReorderQty.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(264, 380);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(100, 32);
            this.btnSave.TabIndex = 17;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.Location = new System.Drawing.Point(372, 380);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(88, 32);
            this.btnCancel.TabIndex = 18;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            // 
            // frmPartEdit
            // 
            this.AcceptButton = this.btnSave;
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.CancelButton = this.btnCancel;
            this.ClientSize = new System.Drawing.Size(480, 430);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.nudReorderQty);
            this.Controls.Add(this.lblReorderQty);
            this.Controls.Add(this.nudReorderLevel);
            this.Controls.Add(this.lblReorderLevel);
            this.Controls.Add(this.lblStock);
            this.Controls.Add(this.nudStock);
            this.Controls.Add(this.lblInStock);
            this.Controls.Add(this.nudSellPrice);
            this.Controls.Add(this.lblSellPrice);
            this.Controls.Add(this.nudUnitCost);
            this.Controls.Add(this.lblUnitCost);
            this.Controls.Add(this.cboSupplier);
            this.Controls.Add(this.lblSupplier);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.lblName);
            this.Controls.Add(this.txtCode);
            this.Controls.Add(this.lblCode);
            this.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmPartEdit";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Part";
            this.Load += new System.EventHandler(this.frmPartEdit_Load);
            ((System.ComponentModel.ISupportInitialize)(this.nudUnitCost)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudSellPrice)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudStock)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudReorderLevel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudReorderQty)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblCode;
        private System.Windows.Forms.TextBox txtCode;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.Label lblSupplier;
        private System.Windows.Forms.ComboBox cboSupplier;
        private System.Windows.Forms.Label lblUnitCost;
        private System.Windows.Forms.NumericUpDown nudUnitCost;
        private System.Windows.Forms.Label lblSellPrice;
        private System.Windows.Forms.NumericUpDown nudSellPrice;
        private System.Windows.Forms.Label lblInStock;
        private System.Windows.Forms.NumericUpDown nudStock;
        private System.Windows.Forms.Label lblStock;
        private System.Windows.Forms.Label lblReorderLevel;
        private System.Windows.Forms.NumericUpDown nudReorderLevel;
        private System.Windows.Forms.Label lblReorderQty;
        private System.Windows.Forms.NumericUpDown nudReorderQty;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnCancel;
    }
}
