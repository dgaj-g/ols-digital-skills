﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using BikeShop.Data;
using BikeShop.Models;

namespace BikeShop.Forms
{
    public partial class frmBikes : Form
    {
        public frmBikes()
        {
            InitializeComponent();
        }

        private void frmBikes_Load(object sender, EventArgs e)
        {
            cboCustomer.DisplayMember = "FullName";
            cboCustomer.ValueMember = "CustomerID";
            cboCustomer.DataSource = CustomerData.Search("");

            // "All bikes" — this also fills the grid (see below)
            cboFilter.SelectedIndex = 0;
        }

        #region LoadBikes
        private void LoadBikes()
        {
            // The filter box holds "All bikes", "For sale" and "Hire fleet";
            // the procedure takes Sale, Hire or nothing.
            string purpose = null;
            if (cboFilter.SelectedIndex == 1)
            {
                purpose = "Sale";
            }
            else if (cboFilter.SelectedIndex == 2)
            {
                purpose = "Hire";
            }

            dgvBikes.DataSource = BikeData.GetAll(purpose);
            Grid.Tidy(dgvBikes, "BikeID");
        }

        private void cboFilter_SelectedIndexChanged(object sender, EventArgs e)
        {
            LoadBikes();
        }
        #endregion

        #region Selection
        // Which buttons make sense depends on the bike's purpose and where it
        // is in its life:
        // Available → Reserved → Sold for a sale bike; Available ↔ In repair
        // for any bike.
        private void dgvBikes_SelectionChanged(object sender, EventArgs e)
        {
            bool picked = dgvBikes.SelectedRows.Count > 0;
            string status = "";
            if (picked)
            {
                status = Grid.SelectedText(dgvBikes, "Status");
            }
            bool forSale = picked
                && Grid.SelectedText(dgvBikes, "Purpose") == "Sale";

            btnReserve.Enabled = forSale && status == "Available";
            btnUnreserve.Enabled = forSale && status == "Reserved";
            btnSell.Enabled = forSale
                && (status == "Available" || status == "Reserved");
            btnRepair.Enabled = picked
                && (status == "Available" || status == "In repair");
            if (status == "In repair")
            {
                btnRepair.Text = "Back in service";
            }
            else
            {
                btnRepair.Text = "Send for repair";
            }

            // A reserved bike can only be sold to the customer who reserved it,
            // so pick them in the box.
            if (status == "Reserved")
            {
                cboCustomer.SelectedIndex =
                    cboCustomer.FindStringExact(Grid.SelectedText(dgvBikes,
                    "Customer"));
            }
        }
        #endregion

        #region Actions
        private void btnAdd_Click(object sender, EventArgs e)
        {
            frmBikeEdit add = new frmBikeEdit();
            if (add.ShowDialog(this) == DialogResult.OK)
            {
                LoadBikes();
            }
        }

        private void btnReserve_Click(object sender, EventArgs e)
        {
            if (cboCustomer.SelectedValue == null)
            {
                Msg.Problem("Choose the customer who is reserving the bike.");
                cboCustomer.Focus();
                return;
            }

            string message =
                BikeData.Reserve(Grid.SelectedID(dgvBikes, "BikeID"),
                (int)cboCustomer.SelectedValue);
            if (message != "")
            {
                Msg.Problem(message);
                return;
            }
            LoadBikes();
        }

        private void btnUnreserve_Click(object sender, EventArgs e)
        {
            if (!Msg.Ask("Take the reservation off the "
                + Grid.SelectedText(dgvBikes, "Bike") + "?"))
            {
                return;
            }

            string message =
                BikeData.Unreserve(Grid.SelectedID(dgvBikes, "BikeID"));
            if (message != "")
            {
                Msg.Problem(message);
                return;
            }
            LoadBikes();
        }

        private void btnSell_Click(object sender, EventArgs e)
        {
            if (cboCustomer.SelectedValue == null)
            {
                Msg.Problem("Choose the customer who is buying the bike.");
                cboCustomer.Focus();
                return;
            }
            string bike = Grid.SelectedText(dgvBikes, "Bike");
            string customer = cboCustomer.Text;
            if (!Msg.Ask("Sell the " + bike + " to " + customer
                + "? A sold bike cannot be sold again."))
            {
                return;
            }

            string message = BikeData.Sell(Grid.SelectedID(dgvBikes, "BikeID"),
                (int)cboCustomer.SelectedValue);
            if (message != "")
            {
                Msg.Problem(message);
                return;
            }
            LoadBikes();
        }

        private void btnRepair_Click(object sender, EventArgs e)
        {
            // The button says "Send for repair" or "Back in service" depending
            // on the bike's status.
            bool sendForRepair = Grid.SelectedText(dgvBikes, "Status")
                != "In repair";

            string message =
                BikeData.SetRepair(Grid.SelectedID(dgvBikes, "BikeID"),
                sendForRepair);
            if (message != "")
            {
                Msg.Problem(message);
                return;
            }
            LoadBikes();
        }
        #endregion

        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
