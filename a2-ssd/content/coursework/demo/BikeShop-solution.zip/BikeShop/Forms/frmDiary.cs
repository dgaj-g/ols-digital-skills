﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using BikeShop.Data;
using BikeShop.Models;

namespace BikeShop.Forms
{
    public partial class frmDiary : Form
    {
        public frmDiary()
        {
            InitializeComponent();
        }

        private void frmDiary_Load(object sender, EventArgs e)
        {
            dtpDay.Value = DateTime.Today;
            LoadDay();
        }

        #region LoadDay
        // One trip to the database gives the day's bookings; the grid and the
        // timeline both show them.
        private void LoadDay()
        {
            DataTable bookings = AppointmentData.GetByDay(dtpDay.Value);
            dgvBookings.DataSource = bookings;
            Grid.Tidy(dgvBookings, "AppointmentID", "MechanicID");
            timeline.ShowDay(dtpDay.Value, bookings);
        }
        #endregion

        private void dtpDay_ValueChanged(object sender, EventArgs e)
        {
            LoadDay();
        }

        private void btnToday_Click(object sender, EventArgs e)
        {
            dtpDay.Value = DateTime.Today;
        }

        #region Selection
        // Move, Mark done and Cancel only apply to a booking that is still
        // "Booked".
        private void dgvBookings_SelectionChanged(object sender, EventArgs e)
        {
            bool picked = dgvBookings.SelectedRows.Count > 0;
            bool booked = picked
                && Grid.SelectedText(dgvBookings, "Status") == "Booked";
            btnMove.Enabled = booked;
            btnDone.Enabled = booked;
            btnCancelBooking.Enabled = booked;

            if (picked)
            {
                timeline.Highlight(Grid.SelectedID(dgvBookings,
                    "AppointmentID"));
            }
            else
            {
                timeline.Highlight(0);
            }
        }

        // A click on a block in the timeline picks the same booking in the
        // grid.
        private void timeline_BookingPicked(object sender,
            BikeShop.Controls.BookingPickedEventArgs e)
        {
            foreach (DataGridViewRow row in dgvBookings.Rows)
            {
                int id = Convert.ToInt32(row.Cells["AppointmentID"].Value);
                if (id == e.AppointmentID)
                {
                    row.Selected = true;
                    dgvBookings.CurrentCell = row.Cells["Customer"];
                    return;
                }
            }
        }
        #endregion

        #region Actions
        private void btnNew_Click(object sender, EventArgs e)
        {
            frmAppointmentEdit booking = new frmAppointmentEdit(dtpDay.Value);
            if (booking.ShowDialog(this) == DialogResult.OK)
            {
                LoadDay();
            }
        }

        private void btnMove_Click(object sender, EventArgs e)
        {
            int appointmentID = Grid.SelectedID(dgvBookings, "AppointmentID");
            DataGridViewRow row = dgvBookings.SelectedRows[0];
            DateTime start = Convert.ToDateTime(row.Cells["StartTime"].Value);
            string summary = Grid.SelectedText(dgvBookings, "Customer") + " · "
                + Grid.SelectedText(dgvBookings, "Service") + " with "
                + Grid.SelectedText(dgvBookings, "Mechanic");

            frmAppointmentEdit move = new frmAppointmentEdit(appointmentID,
                start, summary);
            if (move.ShowDialog(this) == DialogResult.OK)
            {
                LoadDay();
            }
        }

        private void btnDone_Click(object sender, EventArgs e)
        {
            if (!Msg.Ask("Mark the booking for "
                + Grid.SelectedText(dgvBookings, "Customer") + " as done?"))
            {
                return;
            }

            string message =
                AppointmentData.MarkDone(Grid.SelectedID(dgvBookings,
                "AppointmentID"));
            if (message != "")
            {
                Msg.Problem(message);
                return;
            }
            LoadDay();
        }

        private void btnCancelBooking_Click(object sender, EventArgs e)
        {
            string who = Grid.SelectedText(dgvBookings, "Customer");
            if (!Msg.Ask("Cancel " + who
                + "'s booking? It stays in the diary marked Cancelled."))
            {
                return;
            }

            string message =
                AppointmentData.Cancel(Grid.SelectedID(dgvBookings,
                "AppointmentID"));
            if (message != "")
            {
                Msg.Problem(message);
                return;
            }
            LoadDay();
        }
        #endregion

        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
