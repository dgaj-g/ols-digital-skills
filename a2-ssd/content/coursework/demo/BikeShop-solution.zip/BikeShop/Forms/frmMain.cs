﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using BikeShop.Data;
using BikeShop.Models;

namespace BikeShop.Forms
{
    public partial class frmMain : Form
    {
        public frmMain()
        {
            InitializeComponent();
        }

        private void frmMain_Load(object sender, EventArgs e)
        {
            lblSignedIn.Text = "Signed in: " + Session.FullName + " ("
                + Session.Role + ")";

            // Only a manager sees the money.  The button stays visible so
            // everyone knows the report exists.
            btnReports.Enabled = Session.IsManager;
            if (!Session.IsManager)
            {
                btnReports.Text = "Reports (manager only)";
            }
        }

        #region Open
        private void btnCustomers_Click(object sender, EventArgs e)
        {
            frmCustomers customers = new frmCustomers();
            customers.ShowDialog(this);
        }

        private void btnDiary_Click(object sender, EventArgs e)
        {
            frmDiary diary = new frmDiary();
            diary.ShowDialog(this);
        }

        private void btnHires_Click(object sender, EventArgs e)
        {
            frmHires hires = new frmHires();
            hires.ShowDialog(this);
        }

        private void btnBikes_Click(object sender, EventArgs e)
        {
            frmBikes bikes = new frmBikes();
            bikes.ShowDialog(this);
        }

        private void btnParts_Click(object sender, EventArgs e)
        {
            frmParts parts = new frmParts();
            parts.ShowDialog(this);
        }

        private void btnReports_Click(object sender, EventArgs e)
        {
            frmReports reports = new frmReports();
            reports.ShowDialog(this);
        }
        #endregion

        private void btnSignOut_Click(object sender, EventArgs e)
        {
            Session.SignOut();
            Close();        // frmLogin notices the close and shows itself again
        }
    }
}
