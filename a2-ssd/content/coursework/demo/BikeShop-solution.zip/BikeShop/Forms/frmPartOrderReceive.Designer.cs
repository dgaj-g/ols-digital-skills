﻿namespace BikeShop.Forms
{
    partial class frmPartOrderReceive
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblOrderCaption = new System.Windows.Forms.Label();
            this.lblOrder = new System.Windows.Forms.Label();
            this.lblOrdered = new System.Windows.Forms.Label();
            this.lblReceived = new System.Windows.Forms.Label();
            this.nudReceived = new System.Windows.Forms.NumericUpDown();
            this.lblNote = new System.Windows.Forms.Label();
            this.btnReceive = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.nudReceived)).BeginInit();
            this.SuspendLayout();
            // 
            // lblOrderCaption
            // 
            this.lblOrderCaption.AutoSize = true;
            this.lblOrderCaption.Location = new System.Drawing.Point(20, 22);
            this.lblOrderCaption.Name = "lblOrderCaption";
            this.lblOrderCaption.Size = new System.Drawing.Size(46, 19);
            this.lblOrderCaption.TabIndex = 0;
            this.lblOrderCaption.Text = "Order";
            // 
            // lblOrder
            // 
            this.lblOrder.AutoSize = true;
            this.lblOrder.Location = new System.Drawing.Point(120, 22);
            this.lblOrder.Name = "lblOrder";
            this.lblOrder.Size = new System.Drawing.Size(320, 19);
            this.lblOrder.TabIndex = 1;
            this.lblOrder.Text = "";
            // 
            // lblOrdered
            // 
            this.lblOrdered.AutoSize = true;
            this.lblOrdered.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(92)))), ((int)(((byte)(103)))), ((int)(((byte)(116)))));
            this.lblOrdered.Location = new System.Drawing.Point(120, 46);
            this.lblOrdered.Name = "lblOrdered";
            this.lblOrdered.Size = new System.Drawing.Size(320, 19);
            this.lblOrdered.TabIndex = 2;
            this.lblOrdered.Text = "";
            // 
            // lblReceived
            // 
            this.lblReceived.AutoSize = true;
            this.lblReceived.Location = new System.Drawing.Point(20, 87);
            this.lblReceived.Name = "lblReceived";
            this.lblReceived.Size = new System.Drawing.Size(68, 19);
            this.lblReceived.TabIndex = 3;
            this.lblReceived.Text = "Received";
            // 
            // nudReceived
            // 
            this.nudReceived.Location = new System.Drawing.Point(120, 84);
            this.nudReceived.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.nudReceived.Name = "nudReceived";
            this.nudReceived.Size = new System.Drawing.Size(100, 25);
            this.nudReceived.TabIndex = 4;
            // 
            // lblNote
            // 
            this.lblNote.AutoSize = true;
            this.lblNote.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(92)))), ((int)(((byte)(103)))), ((int)(((byte)(116)))));
            this.lblNote.Location = new System.Drawing.Point(120, 118);
            this.lblNote.Name = "lblNote";
            this.lblNote.Size = new System.Drawing.Size(372, 19);
            this.lblNote.TabIndex = 5;
            this.lblNote.Text = "If the box is short, type what actually arrived.";
            // 
            // btnReceive
            // 
            this.btnReceive.Location = new System.Drawing.Point(244, 166);
            this.btnReceive.Name = "btnReceive";
            this.btnReceive.Size = new System.Drawing.Size(100, 32);
            this.btnReceive.TabIndex = 6;
            this.btnReceive.Text = "Receive";
            this.btnReceive.UseVisualStyleBackColor = true;
            this.btnReceive.Click += new System.EventHandler(this.btnReceive_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.Location = new System.Drawing.Point(352, 166);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(88, 32);
            this.btnCancel.TabIndex = 7;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            // 
            // frmPartOrderReceive
            // 
            this.AcceptButton = this.btnReceive;
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.CancelButton = this.btnCancel;
            this.ClientSize = new System.Drawing.Size(460, 220);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnReceive);
            this.Controls.Add(this.lblNote);
            this.Controls.Add(this.nudReceived);
            this.Controls.Add(this.lblReceived);
            this.Controls.Add(this.lblOrdered);
            this.Controls.Add(this.lblOrder);
            this.Controls.Add(this.lblOrderCaption);
            this.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmPartOrderReceive";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Receive a delivery";
            ((System.ComponentModel.ISupportInitialize)(this.nudReceived)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblOrderCaption;
        private System.Windows.Forms.Label lblOrder;
        private System.Windows.Forms.Label lblOrdered;
        private System.Windows.Forms.Label lblReceived;
        private System.Windows.Forms.NumericUpDown nudReceived;
        private System.Windows.Forms.Label lblNote;
        private System.Windows.Forms.Button btnReceive;
        private System.Windows.Forms.Button btnCancel;
    }
}
