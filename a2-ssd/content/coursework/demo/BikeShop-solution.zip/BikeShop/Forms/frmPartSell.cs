﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using BikeShop.Data;
using BikeShop.Models;

namespace BikeShop.Forms
{
    public partial class frmPartSell : Form
    {
        private readonly int partID;

        public frmPartSell(int id, string partName, int inStock)
        {
            InitializeComponent();
            partID = id;
            lblPart.Text = partName;
            lblInStock.Text = "In stock: " + inStock;
        }

        private void frmPartSell_Load(object sender, EventArgs e)
        {
            cboCustomer.DisplayMember = "FullName";
            cboCustomer.ValueMember = "CustomerID";
            cboCustomer.DataSource = CustomerData.Search("");

            chkWalkIn.Checked = true;
        }

        // Most counter sales are to someone without an account: tick the box
        // and the customer list is skipped.
        private void chkWalkIn_CheckedChanged(object sender, EventArgs e)
        {
            cboCustomer.Enabled = !chkWalkIn.Checked;
        }

        #region Sell
        private void btnSell_Click(object sender, EventArgs e)
        {
            // 0 = a walk-in sale, no customer
            int customerID = 0;
            if (!chkWalkIn.Checked)
            {
                if (cboCustomer.SelectedValue == null)
                {
                    Msg.Problem("Choose the customer, or tick Walk-in " +
                        "customer.");
                    cboCustomer.Focus();
                    return;
                }
                customerID = (int)cboCustomer.SelectedValue;
            }

            // The quantity box starts at 1, so it needs no check.
            // The procedure takes the stock off and refuses if there is not
            // enough: "Only 2 in stock."
            string message = PartSaleData.Add(partID, customerID,
                (int)nudQuantity.Value, Session.StaffID);
            if (message != "")
            {
                Msg.Problem(message);
                return;
            }
            DialogResult = DialogResult.OK;
        }
        #endregion
    }
}
