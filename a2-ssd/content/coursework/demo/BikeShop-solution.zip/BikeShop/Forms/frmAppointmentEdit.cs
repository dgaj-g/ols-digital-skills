﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using BikeShop.Data;
using BikeShop.Models;

namespace BikeShop.Forms
{
    public partial class frmAppointmentEdit : Form
    {
        // 0 = a new booking; otherwise the booking being moved
        private readonly int appointmentID;
        // the date and time the form opens on
        private readonly DateTime startWith;
        // "Aoife McCann · Puncture repair with Conor" when moving
        private readonly string movingWhat;

        // New booking on a chosen day
        public frmAppointmentEdit(DateTime day)
        {
            InitializeComponent();
            startWith = day.Date.AddHours(9);
        }

        // Move an existing booking: only the date and time can change
        public frmAppointmentEdit(int id, DateTime currentStart, string summary)
        {
            InitializeComponent();
            appointmentID = id;
            startWith = currentStart;
            movingWhat = summary;
        }

        #region Load
        private void frmAppointmentEdit_Load(object sender, EventArgs e)
        {
            // The two text boxes stop typing at the length the database column
            // holds.
            txtBike.MaxLength = 80;
            txtNotes.MaxLength = 200;

            FillTimes();
            dtpDate.Value = startWith.Date;
            cboStart.SelectedItem = startWith.ToString("HH:mm");

            // Set the two names first, then the DataSource, so the combo box
            // knows what to show and what to keep.
            cboCustomer.DisplayMember = "FullName";
            cboCustomer.ValueMember = "CustomerID";
            cboCustomer.DataSource = CustomerData.Search("");

            // "Puncture repair · 30 min · £15.00"
            cboService.DisplayMember = "Display";
            cboService.ValueMember = "ServiceTypeID";
            cboService.DataSource = ServiceTypeData.GetAll();

            if (appointmentID != 0)
            {
                Text = "Move a booking";
                lblMoving.Text = "Moving: " + movingWhat;
                btnBook.Text = "Move";
                cboCustomer.Enabled = false;
                cboService.Enabled = false;
                cboMechanic.Enabled = false;
                txtBike.Enabled = false;
                txtNotes.Enabled = false;
                lblMechanicNote.Text = "The same mechanic keeps the job.";
            }
            else
            {
                lblMoving.Text = "";
                RefreshMechanics();
            }
        }

        // The shop opens 08:30 and the last slot starts 17:15: a time every 15
        // minutes.
        private void FillTimes()
        {
            cboStart.Items.Clear();
            TimeSpan time = new TimeSpan(8, 30, 0);
            while (time <= new TimeSpan(17, 15, 0))
            {
                cboStart.Items.Add(time.ToString(@"hh\:mm"));
                time = time.Add(TimeSpan.FromMinutes(15));
            }
        }
        #endregion

        // The chosen date and time as one value, which is what the database
        // stores.
        private DateTime ChosenStart()
        {
            string time = "09:00";
            if (cboStart.SelectedItem != null)
            {
                time = (string)cboStart.SelectedItem;
            }
            return dtpDate.Value.Date + TimeSpan.Parse(time);
        }

        #region FreeMechanics
        // Asks the database which mechanics are free for this service at this
        // time.
        // Runs again whenever the date, the time or the service changes.
        private void RefreshMechanics()
        {
            if (appointmentID != 0 || cboService.SelectedValue == null
                || cboStart.SelectedItem == null)
            {
                return;
            }

            cboMechanic.DisplayMember = "FullName";
            cboMechanic.ValueMember = "StaffID";
            cboMechanic.DataSource = AppointmentData.GetFreeMechanics(
                ChosenStart(), (int)cboService.SelectedValue);

            int free = cboMechanic.Items.Count;
            if (free == 0)
            {
                lblMechanicNote.Text =
                    "No mechanic is free then. Try another time.";
            }
            else if (free == 1)
            {
                lblMechanicNote.Text = "1 mechanic is free.";
            }
            else
            {
                lblMechanicNote.Text = free + " mechanics are free.";
            }
            btnBook.Enabled = free > 0;
        }

        private void cboService_SelectedIndexChanged(object sender, EventArgs e)
        {
            RefreshMechanics();
        }

        private void dtpDate_ValueChanged(object sender, EventArgs e)
        {
            RefreshMechanics();
        }

        private void cboStart_SelectedIndexChanged(object sender, EventArgs e)
        {
            RefreshMechanics();
        }
        #endregion

        #region Book
        private void btnBook_Click(object sender, EventArgs e)
        {
            if (appointmentID != 0)
            {
                MoveBooking();
                return;
            }

            // Check what was chosen and typed, one problem at a time: show the
            // first and put the cursor there.
            if (ChosenID(cboCustomer) == 0)
            {
                Msg.Problem("Choose the customer.");
                cboCustomer.Focus();
                return;
            }
            if (ChosenID(cboService) == 0)
            {
                Msg.Problem("Choose the service.");
                cboService.Focus();
                return;
            }
            if (ChosenID(cboMechanic) == 0)
            {
                Msg.Problem("Choose a mechanic.");
                cboMechanic.Focus();
                return;
            }
            // The start time needs no check: the list only offers times in
            // 15-minute steps.
            if (txtBike.Text.Trim() == "")
            {
                Msg.Problem("Type a description of the bike.");
                txtBike.Focus();
                return;
            }

            Appointment booking = new Appointment();
            booking.CustomerID = ChosenID(cboCustomer);
            booking.ServiceTypeID = ChosenID(cboService);
            booking.MechanicID = ChosenID(cboMechanic);
            booking.StartTime = ChosenStart();
            booking.BikeDescription = txtBike.Text.Trim();
            booking.Notes = txtNotes.Text.Trim();
            if (booking.Notes == "")
            {
                // nothing typed: store a NULL, not an empty piece of text
                booking.Notes = null;
            }
            booking.BookedByStaffID = Session.StaffID;

            // The database checks the clash, the hours and the day, and answers
            // in words.
            string message = AppointmentData.Add(booking);
            if (message != "")
            {
                // e.g. "That mechanic already has a booking in that time."
                Msg.Problem(message);
                // the list may have changed since it was filled
                RefreshMechanics();
                return;
            }
            DialogResult = DialogResult.OK;
        }

        private void MoveBooking()
        {
            string message = AppointmentData.Move(appointmentID, ChosenStart());
            if (message != "")
            {
                Msg.Problem(message);
                return;
            }
            DialogResult = DialogResult.OK;
        }

        // A combo box with nothing chosen gives null; this turns that into 0.
        private int ChosenID(ComboBox combo)
        {
            if (combo.SelectedValue == null)
            {
                return 0;
            }
            return (int)combo.SelectedValue;
        }
        #endregion
    }
}
