﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using BikeShop.Data;
using BikeShop.Models;

namespace BikeShop.Forms
{
    public partial class frmReports : Form
    {
        public frmReports()
        {
            InitializeComponent();
        }

        private void frmReports_Load(object sender, EventArgs e)
        {
            cboReport.SelectedIndex = 0;
            dtpFrom.Value = DateTime.Today.AddDays(-30);
            dtpTo.Value = DateTime.Today;
            lblTotal.Text = "";
        }

        #region Run
        private void btnRun_Click(object sender, EventArgs e)
        {
            if (cboReport.SelectedIndex == 0)
            {
                dgvReport.DataSource =
                    ReportData.MechanicWorkload(dtpFrom.Value, dtpTo.Value);
            }
            else
            {
                dgvReport.DataSource = ReportData.Income(dtpFrom.Value,
                    dtpTo.Value);
            }

            Grid.Tidy(dgvReport);
            ShowTotal();
            btnCopy.Enabled = dgvReport.Rows.Count > 0;
        }

        // Adds up the Income column so the total is on screen, not left to a
        // calculator.
        private void ShowTotal()
        {
            decimal total = 0;
            foreach (DataGridViewRow row in dgvReport.Rows)
            {
                total = total + Convert.ToDecimal(row.Cells["Income"].Value);
            }

            if (dgvReport.Rows.Count == 0)
            {
                lblTotal.Text = "Nothing in those dates.";
            }
            else
            {
                lblTotal.Text = dgvReport.Rows.Count + " rows · total income £"
                    + total.ToString("#,##0.00");
            }
        }
        #endregion

        #region Copy
        // Copies the grid with its headers, ready to paste into Word or Excel
        // for the user guide or the test evidence.
        private void btnCopy_Click(object sender, EventArgs e)
        {
            dgvReport.ClipboardCopyMode =
                DataGridViewClipboardCopyMode.EnableAlwaysIncludeHeaderText;
            dgvReport.SelectAll();
            DataObject content = dgvReport.GetClipboardContent();
            if (content != null)
            {
                Clipboard.SetDataObject(content);
            }
            dgvReport.ClearSelection();
            Msg.Info("Copied. Paste it into Word or Excel.");
        }
        #endregion

        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
