﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using BikeShop.Data;
using BikeShop.Models;

namespace BikeShop.Forms
{
    public partial class frmPartOrderReceive : Form
    {
        private readonly int partOrderID;

        public frmPartOrderReceive(int id, string summary, int qtyOrdered)
        {
            InitializeComponent();
            partOrderID = id;
            lblOrder.Text = summary;
            lblOrdered.Text = qtyOrdered + " ordered";
            // usually the whole order arrives; change it if the box is short
            nudReceived.Value = qtyOrdered;
        }

        #region Receive
        private void btnReceive_Click(object sender, EventArgs e)
        {
            // One procedure call closes the order AND adds to the stock.
            // The quantity box does not go below 0, so it needs no check.
            string message = PartOrderData.Receive(partOrderID,
                (int)nudReceived.Value);
            if (message != "")
            {
                Msg.Problem(message);
                return;
            }
            DialogResult = DialogResult.OK;
        }
        #endregion
    }
}
