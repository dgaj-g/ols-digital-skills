﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using BikeShop.Data;
using BikeShop.Models;

namespace BikeShop.Forms
{
    public partial class frmPartOrderPlace : Form
    {
        private readonly int partID;

        public frmPartOrderPlace(int id, string partName, int suggestedQty)
        {
            InitializeComponent();
            partID = id;
            lblPart.Text = partName;
            // the part's usual reorder amount, ready to change
            nudQuantity.Value = Math.Max(1, suggestedQty);
        }

        private void frmPartOrderPlace_Load(object sender, EventArgs e)
        {
            dtpExpected.Value = DateTime.Today.AddDays(7);
        }

        #region Place
        private void btnPlace_Click(object sender, EventArgs e)
        {
            // The quantity box starts at 1, so it needs no check.  The database
            // checks the expected date.
            string message = PartOrderData.Place(partID, (int)nudQuantity.Value,
                dtpExpected.Value, Session.StaffID);
            if (message != "")
            {
                // e.g. the expected date is in the past
                Msg.Problem(message);
                return;
            }
            DialogResult = DialogResult.OK;
        }
        #endregion
    }
}
