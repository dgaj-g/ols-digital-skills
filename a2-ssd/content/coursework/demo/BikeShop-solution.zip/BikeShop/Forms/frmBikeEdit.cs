﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using BikeShop.Data;
using BikeShop.Models;

namespace BikeShop.Forms
{
    public partial class frmBikeEdit : Form
    {
        public frmBikeEdit()
        {
            InitializeComponent();
        }

        private void frmBikeEdit_Load(object sender, EventArgs e)
        {
            // The boxes stop typing at the length the database column holds.
            txtFrame.MaxLength = 20;
            txtMake.MaxLength = 30;
            txtModel.MaxLength = 40;
            txtColour.MaxLength = 20;

            cboSize.SelectedIndex = 2;      // M
            rdoHire.Checked = true;
            ShowPriceBox();
        }

        #region Purpose
        // A hire bike has a daily rate; a bike for sale has a price.  Only the
        // box that applies is switched on.
        private void ShowPriceBox()
        {
            lblRate.Enabled = rdoHire.Checked;
            nudRate.Enabled = rdoHire.Checked;
            lblPrice.Enabled = rdoSale.Checked;
            nudPrice.Enabled = rdoSale.Checked;
        }

        private void rdoHire_CheckedChanged(object sender, EventArgs e)
        {
            ShowPriceBox();
        }

        private void rdoSale_CheckedChanged(object sender, EventArgs e)
        {
            ShowPriceBox();
        }
        #endregion

        #region Save
        private void btnSave_Click(object sender, EventArgs e)
        {
            // Check what was typed, one problem at a time: show the first and
            // put the cursor there.
            // The size list and the Hire / Sale buttons need no check: one
            // choice is always picked.
            if (txtFrame.Text.Trim() == "")
            {
                Msg.Problem("Type the frame number.");
                txtFrame.Focus();
                return;
            }
            if (txtMake.Text.Trim() == "")
            {
                Msg.Problem("Type the bike's make.");
                txtMake.Focus();
                return;
            }
            if (txtModel.Text.Trim() == "")
            {
                Msg.Problem("Type the bike's model.");
                txtModel.Focus();
                return;
            }
            if (txtColour.Text.Trim() == "")
            {
                Msg.Problem("Type the bike's colour.");
                txtColour.Focus();
                return;
            }
            if (rdoHire.Checked && nudRate.Value <= 0)
            {
                Msg.Problem("A hire bike needs a daily rate above £0.");
                nudRate.Focus();
                return;
            }
            if (rdoSale.Checked && nudPrice.Value <= 0)
            {
                Msg.Problem("A bike for sale needs a sale price above £0.");
                nudPrice.Focus();
                return;
            }

            Bike bike = new Bike();
            bike.FrameNumber = txtFrame.Text.Trim().ToUpper();
            bike.Make = txtMake.Text.Trim();
            bike.Model = txtModel.Text.Trim();
            bike.Size = cboSize.Text;
            bike.Colour = txtColour.Text.Trim();
            if (rdoHire.Checked)
            {
                bike.Purpose = "Hire";
                bike.DailyRate = nudRate.Value;
            }
            else
            {
                bike.Purpose = "Sale";
                bike.SalePrice = nudPrice.Value;
            }

            string message = BikeData.Add(bike);
            if (message != "")
            {
                // e.g. that frame number is already on a bike
                Msg.Problem(message);
                return;
            }
            DialogResult = DialogResult.OK;
        }
        #endregion
    }
}
