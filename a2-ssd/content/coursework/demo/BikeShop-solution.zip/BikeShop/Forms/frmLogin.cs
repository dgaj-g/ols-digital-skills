﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;
using BikeShop.Data;
using BikeShop.Models;

namespace BikeShop.Forms
{
    public partial class frmLogin : Form
    {
        public frmLogin()
        {
            InitializeComponent();
        }

        #region SignIn
        private void btnSignIn_Click(object sender, EventArgs e)
        {
            lblMessage.Text = "";
            string username = txtUsername.Text.Trim();
            string password = txtPassword.Text;

            if (username == "" || password == "")
            {
                lblMessage.Text = "Type your username and your password.";
                return;
            }

            // One row comes back when the details match an active member of
            // staff; no rows when they do not.
            // If SQL Server itself cannot be reached, say so instead of
            // crashing.
            DataTable match;
            try
            {
                match = StaffData.Login(username, password);
            }
            catch (SqlException)
            {
                lblMessage.Text =
                    "Could not reach the database. Is SQL Server running?";
                return;
            }
            if (match.Rows.Count == 0)
            {
                lblMessage.Text =
                    "Those details are not recognised. Check them and try " +
                    "again.";
                txtPassword.Clear();
                txtPassword.Focus();
                return;
            }

            DataRow staff = match.Rows[0];
            Session.SignIn((int)staff["StaffID"], (string)staff["FullName"],
                (string)staff["Role"]);

            frmMain main = new frmMain();
            // so we know when the main window closes
            main.FormClosed += Main_FormClosed;
            Hide();
            main.Show();
        }
        #endregion

        // The main window has closed.  After Sign out we come back here; after
        // the X the program ends.
        private void Main_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (Session.IsSignedIn)
            {
                Close();
            }
            else
            {
                txtPassword.Clear();
                Show();
                txtUsername.Focus();
            }
        }
    }
}
