﻿namespace BikeShop.Forms
{
    partial class frmPartOrderPlace
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblPartCaption = new System.Windows.Forms.Label();
            this.lblPart = new System.Windows.Forms.Label();
            this.lblQty = new System.Windows.Forms.Label();
            this.nudQuantity = new System.Windows.Forms.NumericUpDown();
            this.lblExpected = new System.Windows.Forms.Label();
            this.dtpExpected = new System.Windows.Forms.DateTimePicker();
            this.lblNote = new System.Windows.Forms.Label();
            this.btnPlace = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.nudQuantity)).BeginInit();
            this.SuspendLayout();
            // 
            // lblPartCaption
            // 
            this.lblPartCaption.AutoSize = true;
            this.lblPartCaption.Location = new System.Drawing.Point(20, 22);
            this.lblPartCaption.Name = "lblPartCaption";
            this.lblPartCaption.Size = new System.Drawing.Size(38, 19);
            this.lblPartCaption.TabIndex = 0;
            this.lblPartCaption.Text = "Part";
            // 
            // lblPart
            // 
            this.lblPart.AutoSize = true;
            this.lblPart.Location = new System.Drawing.Point(120, 22);
            this.lblPart.Name = "lblPart";
            this.lblPart.Size = new System.Drawing.Size(300, 19);
            this.lblPart.TabIndex = 1;
            this.lblPart.Text = "";
            // 
            // lblQty
            // 
            this.lblQty.AutoSize = true;
            this.lblQty.Location = new System.Drawing.Point(20, 63);
            this.lblQty.Name = "lblQty";
            this.lblQty.Size = new System.Drawing.Size(68, 19);
            this.lblQty.TabIndex = 2;
            this.lblQty.Text = "Quantity";
            // 
            // nudQuantity
            // 
            this.nudQuantity.Location = new System.Drawing.Point(120, 60);
            this.nudQuantity.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.nudQuantity.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudQuantity.Name = "nudQuantity";
            this.nudQuantity.Size = new System.Drawing.Size(100, 25);
            this.nudQuantity.TabIndex = 3;
            this.nudQuantity.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // lblExpected
            // 
            this.lblExpected.AutoSize = true;
            this.lblExpected.Location = new System.Drawing.Point(20, 103);
            this.lblExpected.Name = "lblExpected";
            this.lblExpected.Size = new System.Drawing.Size(91, 19);
            this.lblExpected.TabIndex = 4;
            this.lblExpected.Text = "Expected on";
            // 
            // dtpExpected
            // 
            this.dtpExpected.Format = System.Windows.Forms.DateTimePickerFormat.Long;
            this.dtpExpected.Location = new System.Drawing.Point(120, 100);
            this.dtpExpected.Name = "dtpExpected";
            this.dtpExpected.Size = new System.Drawing.Size(240, 25);
            this.dtpExpected.TabIndex = 5;
            // 
            // lblNote
            // 
            this.lblNote.AutoSize = true;
            this.lblNote.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(92)))), ((int)(((byte)(103)))), ((int)(((byte)(116)))));
            this.lblNote.Location = new System.Drawing.Point(20, 142);
            this.lblNote.Name = "lblNote";
            this.lblNote.Size = new System.Drawing.Size(410, 19);
            this.lblNote.TabIndex = 6;
            this.lblNote.Text = "Stock goes up when the delivery is received, not now.";
            // 
            // btnPlace
            // 
            this.btnPlace.Location = new System.Drawing.Point(204, 186);
            this.btnPlace.Name = "btnPlace";
            this.btnPlace.Size = new System.Drawing.Size(120, 32);
            this.btnPlace.TabIndex = 7;
            this.btnPlace.Text = "Place order";
            this.btnPlace.UseVisualStyleBackColor = true;
            this.btnPlace.Click += new System.EventHandler(this.btnPlace_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.Location = new System.Drawing.Point(332, 186);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(88, 32);
            this.btnCancel.TabIndex = 8;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            // 
            // frmPartOrderPlace
            // 
            this.AcceptButton = this.btnPlace;
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.CancelButton = this.btnCancel;
            this.ClientSize = new System.Drawing.Size(440, 240);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnPlace);
            this.Controls.Add(this.lblNote);
            this.Controls.Add(this.dtpExpected);
            this.Controls.Add(this.lblExpected);
            this.Controls.Add(this.nudQuantity);
            this.Controls.Add(this.lblQty);
            this.Controls.Add(this.lblPart);
            this.Controls.Add(this.lblPartCaption);
            this.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmPartOrderPlace";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Place an order";
            this.Load += new System.EventHandler(this.frmPartOrderPlace_Load);
            ((System.ComponentModel.ISupportInitialize)(this.nudQuantity)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblPartCaption;
        private System.Windows.Forms.Label lblPart;
        private System.Windows.Forms.Label lblQty;
        private System.Windows.Forms.NumericUpDown nudQuantity;
        private System.Windows.Forms.Label lblExpected;
        private System.Windows.Forms.DateTimePicker dtpExpected;
        private System.Windows.Forms.Label lblNote;
        private System.Windows.Forms.Button btnPlace;
        private System.Windows.Forms.Button btnCancel;
    }
}
