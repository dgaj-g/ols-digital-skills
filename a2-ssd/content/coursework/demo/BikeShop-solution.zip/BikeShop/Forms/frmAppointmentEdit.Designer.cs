﻿namespace BikeShop.Forms
{
    partial class frmAppointmentEdit
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblMoving = new System.Windows.Forms.Label();
            this.lblCustomer = new System.Windows.Forms.Label();
            this.cboCustomer = new System.Windows.Forms.ComboBox();
            this.lblService = new System.Windows.Forms.Label();
            this.cboService = new System.Windows.Forms.ComboBox();
            this.lblDate = new System.Windows.Forms.Label();
            this.dtpDate = new System.Windows.Forms.DateTimePicker();
            this.lblStart = new System.Windows.Forms.Label();
            this.cboStart = new System.Windows.Forms.ComboBox();
            this.lblMechanic = new System.Windows.Forms.Label();
            this.cboMechanic = new System.Windows.Forms.ComboBox();
            this.lblMechanicNote = new System.Windows.Forms.Label();
            this.lblBike = new System.Windows.Forms.Label();
            this.txtBike = new System.Windows.Forms.TextBox();
            this.lblNotes = new System.Windows.Forms.Label();
            this.txtNotes = new System.Windows.Forms.TextBox();
            this.btnBook = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblMoving
            // 
            this.lblMoving.AutoSize = true;
            this.lblMoving.Location = new System.Drawing.Point(20, 14);
            this.lblMoving.Name = "lblMoving";
            this.lblMoving.Size = new System.Drawing.Size(480, 20);
            this.lblMoving.TabIndex = 0;
            this.lblMoving.Text = "";
            // 
            // lblCustomer
            // 
            this.lblCustomer.AutoSize = true;
            this.lblCustomer.Location = new System.Drawing.Point(20, 47);
            this.lblCustomer.Name = "lblCustomer";
            this.lblCustomer.Size = new System.Drawing.Size(68, 19);
            this.lblCustomer.TabIndex = 1;
            this.lblCustomer.Text = "Customer";
            // 
            // cboCustomer
            // 
            this.cboCustomer.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboCustomer.Location = new System.Drawing.Point(160, 44);
            this.cboCustomer.Name = "cboCustomer";
            this.cboCustomer.Size = new System.Drawing.Size(330, 25);
            this.cboCustomer.TabIndex = 2;
            // 
            // lblService
            // 
            this.lblService.AutoSize = true;
            this.lblService.Location = new System.Drawing.Point(20, 87);
            this.lblService.Name = "lblService";
            this.lblService.Size = new System.Drawing.Size(61, 19);
            this.lblService.TabIndex = 3;
            this.lblService.Text = "Service";
            // 
            // cboService
            // 
            this.cboService.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboService.Location = new System.Drawing.Point(160, 84);
            this.cboService.Name = "cboService";
            this.cboService.Size = new System.Drawing.Size(330, 25);
            this.cboService.TabIndex = 4;
            this.cboService.SelectedIndexChanged += new System.EventHandler(this.cboService_SelectedIndexChanged);
            // 
            // lblDate
            // 
            this.lblDate.AutoSize = true;
            this.lblDate.Location = new System.Drawing.Point(20, 127);
            this.lblDate.Name = "lblDate";
            this.lblDate.Size = new System.Drawing.Size(38, 19);
            this.lblDate.TabIndex = 5;
            this.lblDate.Text = "Date";
            // 
            // dtpDate
            // 
            this.dtpDate.Format = System.Windows.Forms.DateTimePickerFormat.Long;
            this.dtpDate.Location = new System.Drawing.Point(160, 124);
            this.dtpDate.Name = "dtpDate";
            this.dtpDate.Size = new System.Drawing.Size(240, 25);
            this.dtpDate.TabIndex = 6;
            this.dtpDate.ValueChanged += new System.EventHandler(this.dtpDate_ValueChanged);
            // 
            // lblStart
            // 
            this.lblStart.AutoSize = true;
            this.lblStart.Location = new System.Drawing.Point(20, 167);
            this.lblStart.Name = "lblStart";
            this.lblStart.Size = new System.Drawing.Size(84, 19);
            this.lblStart.TabIndex = 7;
            this.lblStart.Text = "Start time";
            // 
            // cboStart
            // 
            this.cboStart.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboStart.Location = new System.Drawing.Point(160, 164);
            this.cboStart.Name = "cboStart";
            this.cboStart.Size = new System.Drawing.Size(100, 25);
            this.cboStart.TabIndex = 8;
            this.cboStart.SelectedIndexChanged += new System.EventHandler(this.cboStart_SelectedIndexChanged);
            // 
            // lblMechanic
            // 
            this.lblMechanic.AutoSize = true;
            this.lblMechanic.Location = new System.Drawing.Point(20, 207);
            this.lblMechanic.Name = "lblMechanic";
            this.lblMechanic.Size = new System.Drawing.Size(68, 19);
            this.lblMechanic.TabIndex = 9;
            this.lblMechanic.Text = "Mechanic";
            // 
            // cboMechanic
            // 
            this.cboMechanic.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboMechanic.Location = new System.Drawing.Point(160, 204);
            this.cboMechanic.Name = "cboMechanic";
            this.cboMechanic.Size = new System.Drawing.Size(330, 25);
            this.cboMechanic.TabIndex = 10;
            // 
            // lblMechanicNote
            // 
            this.lblMechanicNote.AutoSize = true;
            this.lblMechanicNote.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(92)))), ((int)(((byte)(103)))), ((int)(((byte)(116)))));
            this.lblMechanicNote.Location = new System.Drawing.Point(160, 232);
            this.lblMechanicNote.Name = "lblMechanicNote";
            this.lblMechanicNote.Size = new System.Drawing.Size(330, 19);
            this.lblMechanicNote.TabIndex = 11;
            this.lblMechanicNote.Text = "";
            // 
            // lblBike
            // 
            this.lblBike.AutoSize = true;
            this.lblBike.Location = new System.Drawing.Point(20, 267);
            this.lblBike.Name = "lblBike";
            this.lblBike.Size = new System.Drawing.Size(38, 19);
            this.lblBike.TabIndex = 12;
            this.lblBike.Text = "Bike";
            // 
            // txtBike
            // 
            this.txtBike.Location = new System.Drawing.Point(160, 264);
            this.txtBike.Name = "txtBike";
            this.txtBike.Size = new System.Drawing.Size(330, 25);
            this.txtBike.TabIndex = 13;
            // 
            // lblNotes
            // 
            this.lblNotes.AutoSize = true;
            this.lblNotes.Location = new System.Drawing.Point(20, 307);
            this.lblNotes.Name = "lblNotes";
            this.lblNotes.Size = new System.Drawing.Size(46, 19);
            this.lblNotes.TabIndex = 14;
            this.lblNotes.Text = "Notes";
            // 
            // txtNotes
            // 
            this.txtNotes.Location = new System.Drawing.Point(160, 304);
            this.txtNotes.Multiline = true;
            this.txtNotes.Name = "txtNotes";
            this.txtNotes.Size = new System.Drawing.Size(330, 70);
            this.txtNotes.TabIndex = 15;
            // 
            // btnBook
            // 
            this.btnBook.Location = new System.Drawing.Point(304, 410);
            this.btnBook.Name = "btnBook";
            this.btnBook.Size = new System.Drawing.Size(100, 32);
            this.btnBook.TabIndex = 16;
            this.btnBook.Text = "Book";
            this.btnBook.UseVisualStyleBackColor = true;
            this.btnBook.Click += new System.EventHandler(this.btnBook_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.Location = new System.Drawing.Point(412, 410);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(100, 32);
            this.btnCancel.TabIndex = 17;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            // 
            // frmAppointmentEdit
            // 
            this.AcceptButton = this.btnBook;
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.CancelButton = this.btnCancel;
            this.ClientSize = new System.Drawing.Size(520, 470);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnBook);
            this.Controls.Add(this.txtNotes);
            this.Controls.Add(this.lblNotes);
            this.Controls.Add(this.txtBike);
            this.Controls.Add(this.lblBike);
            this.Controls.Add(this.lblMechanicNote);
            this.Controls.Add(this.cboMechanic);
            this.Controls.Add(this.lblMechanic);
            this.Controls.Add(this.cboStart);
            this.Controls.Add(this.lblStart);
            this.Controls.Add(this.dtpDate);
            this.Controls.Add(this.lblDate);
            this.Controls.Add(this.cboService);
            this.Controls.Add(this.lblService);
            this.Controls.Add(this.cboCustomer);
            this.Controls.Add(this.lblCustomer);
            this.Controls.Add(this.lblMoving);
            this.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmAppointmentEdit";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "New booking";
            this.Load += new System.EventHandler(this.frmAppointmentEdit_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblMoving;
        private System.Windows.Forms.Label lblCustomer;
        private System.Windows.Forms.ComboBox cboCustomer;
        private System.Windows.Forms.Label lblService;
        private System.Windows.Forms.ComboBox cboService;
        private System.Windows.Forms.Label lblDate;
        private System.Windows.Forms.DateTimePicker dtpDate;
        private System.Windows.Forms.Label lblStart;
        private System.Windows.Forms.ComboBox cboStart;
        private System.Windows.Forms.Label lblMechanic;
        private System.Windows.Forms.ComboBox cboMechanic;
        private System.Windows.Forms.Label lblMechanicNote;
        private System.Windows.Forms.Label lblBike;
        private System.Windows.Forms.TextBox txtBike;
        private System.Windows.Forms.Label lblNotes;
        private System.Windows.Forms.TextBox txtNotes;
        private System.Windows.Forms.Button btnBook;
        private System.Windows.Forms.Button btnCancel;
    }
}
