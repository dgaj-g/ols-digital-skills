﻿using System;
using System.Text;
using System.Windows.Forms;

namespace BikeShop
{
    // Small helpers every grid uses.  Call Tidy straight after you set a grid's
    // DataSource.
    public static class Grid
    {
        #region Tidy
        // Hides the ID columns (the user never needs a number) and turns column
        // names into plain headers.
        public static void Tidy(DataGridView grid,
            params string[] hiddenColumns)
        {
            foreach (string name in hiddenColumns)
                if (grid.Columns.Contains(name)) grid.Columns[name].Visible =
                    false;

            foreach (DataGridViewColumn column in grid.Columns)
            {
                column.HeaderText = Words(column.Name);
                if (column.ValueType == typeof(decimal) && IsMoney(column.Name))
                {
                    column.DefaultCellStyle.Format = "£#,##0.00";
                    column.DefaultCellStyle.Alignment =
                        DataGridViewContentAlignment.MiddleRight;
                }
                else if (column.ValueType == typeof(DateTime))
                {
                    column.DefaultCellStyle.Format = "ddd d MMM yyyy";
                    if (column.Name.Contains("Time"))
                    {
                        column.DefaultCellStyle.Format = "HH:mm";
                    }
                }
            }
            grid.ClearSelection();
        }

        private static bool IsMoney(string name)
        {
            return name.Contains("Price") || name.Contains("Rate")
                || name.Contains("Cost") || name.Contains("Income")
                || name.Contains("Deposit") || name.Contains("Total")
                    || name.Contains("Paid");
        }
        #endregion

        #region Words
        // "BikeDescription" → "Bike description", "QtyInStock" → "Qty in
        // stock", "Mechanic" → "Mechanic"
        public static string Words(string columnName)
        {
            StringBuilder words = new StringBuilder();
            for (int i = 0; i < columnName.Length; i++)
            {
                char c = columnName[i];
                if (i > 0 && char.IsUpper(c) && char.IsLower(columnName[i - 1]))
                {
                    words.Append(' ');
                    words.Append(char.ToLower(c));
                }
                else
                {
                    words.Append(c);
                }
            }
            return words.ToString();
        }
        #endregion

        #region Selected
        // The hidden ID of the picked row (0 when nothing is picked).
        public static int SelectedID(DataGridView grid, string idColumn)
        {
            if (grid.SelectedRows.Count == 0) return 0;
            return Convert.ToInt32(grid.SelectedRows[0].Cells[idColumn].Value);
        }

        // A text value from the picked row ("" when nothing is picked).
        public static string SelectedText(DataGridView grid, string column)
        {
            if (grid.SelectedRows.Count == 0) return "";
            return Convert.ToString(grid.SelectedRows[0].Cells[column].Value);
        }
        #endregion
    }
}
