﻿using System;
using System.Data;
using System.Data.SqlClient;
using BikeShop.Models;

namespace BikeShop.Data
{
    public static class HireData
    {
        #region Add
        // Saves a new hire.  The procedure refuses if the bike is already out
        // on those days.
        // Returns "" if it worked, or the sentence to show the user.
        public static string Add(Hire hire)
        {
            SqlParameter newID = Db.Out("@NewHireID");
            string message = Db.Run("usp_Hire_Add",
                Db.P("@BikeID", hire.BikeID),
                Db.P("@CustomerID", hire.CustomerID),
                Db.P("@StartDate", hire.StartDate),
                Db.P("@EndDate", hire.EndDate),
                Db.P("@DepositPaid", hire.DepositPaid),
                Db.P("@BookedByStaffID", hire.BookedByStaffID),
                newID);
            if (message == "")
            {
                hire.HireID = (int)newID.Value;
            }
            return message;
        }
        #endregion

        // The hires that start between two dates.
        public static DataTable GetByDateRange(DateTime fromDate,
            DateTime toDate)
        {
            return Db.GetTable("usp_Hire_GetByDateRange",
                Db.P("@FromDate", fromDate.Date), Db.P("@ToDate", toDate.Date));
        }

        // The hire history of one bike.
        public static DataTable GetForBike(int bikeID)
        {
            return Db.GetTable("usp_Hire_GetForBike", Db.P("@BikeID", bikeID));
        }

        // The customer picks the bike up.
        public static string CheckOut(int hireID)
        {
            return Db.Run("usp_Hire_CheckOut", Db.P("@HireID", hireID));
        }

        // The customer brings the bike back.
        public static string Return(int hireID)
        {
            return Db.Run("usp_Hire_Return", Db.P("@HireID", hireID));
        }

        // Cancels a hire that has not started yet.
        public static string Cancel(int hireID)
        {
            return Db.Run("usp_Hire_Cancel", Db.P("@HireID", hireID));
        }
    }
}
