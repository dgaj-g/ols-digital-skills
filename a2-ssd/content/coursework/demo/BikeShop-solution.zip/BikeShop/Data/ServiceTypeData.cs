﻿using System.Data;
using System.Data.SqlClient;
using BikeShop.Models;

namespace BikeShop.Data
{
    public static class ServiceTypeData
    {
        // Every kind of service.
        public static DataTable GetAll()
        {
            return Db.GetTable("usp_ServiceType_GetAll");
        }

        // Saves a new service.  Returns "" if it worked, or the sentence to
        // show the user.
        public static string Add(ServiceType service)
        {
            SqlParameter newID = Db.Out("@NewServiceTypeID");
            string message = Db.Run("usp_ServiceType_Add",
                Db.P("@Name", service.Name),
                Db.P("@DurationMinutes", service.DurationMinutes),
                Db.P("@Price", service.Price),
                newID);
            if (message == "")
            {
                service.ServiceTypeID = (int)newID.Value;
            }
            return message;
        }

        // Saves changes to an existing service.
        public static string Update(ServiceType service)
        {
            return Db.Run("usp_ServiceType_Update",
                Db.P("@ServiceTypeID", service.ServiceTypeID),
                Db.P("@Name", service.Name),
                Db.P("@DurationMinutes", service.DurationMinutes),
                Db.P("@Price", service.Price));
        }
    }
}
