﻿using System;
using System.Data;
using System.Data.SqlClient;
using BikeShop.Models;

namespace BikeShop.Data
{
    public static class AppointmentData
    {
        #region GetByDay
        // Every booking on one day.
        public static DataTable GetByDay(DateTime day)
        {
            return Db.GetTable("usp_Appointment_GetByDay",
                Db.P("@Day", day.Date));
        }
        #endregion

        #region GetFreeMechanics
        // The mechanics who are free for the whole length of this service,
        // starting at this time.
        public static DataTable GetFreeMechanics(DateTime startTime,
            int serviceTypeID)
        {
            return Db.GetTable("usp_Appointment_GetFreeMechanics",
                Db.P("@StartTime", startTime),
                Db.P("@ServiceTypeID", serviceTypeID));
        }
        #endregion

        // All the bookings for one customer.
        public static DataTable GetForCustomer(int customerID)
        {
            return Db.GetTable("usp_Appointment_GetForCustomer",
                Db.P("@CustomerID", customerID));
        }

        #region Add
        // Saves a new booking.  The procedure works out the end time and
        // refuses a clash.
        // Returns "" if it worked, or the sentence to show the user.
        public static string Add(Appointment appointment)
        {
            SqlParameter newID = Db.Out("@NewAppointmentID");
            string message = Db.Run("usp_Appointment_Add",
                Db.P("@CustomerID", appointment.CustomerID),
                Db.P("@MechanicID", appointment.MechanicID),
                Db.P("@ServiceTypeID", appointment.ServiceTypeID),
                Db.P("@StartTime", appointment.StartTime),
                Db.P("@BikeDescription", appointment.BikeDescription),
                Db.P("@Notes", appointment.Notes),
                Db.P("@BookedByStaffID", appointment.BookedByStaffID),
                newID);
            if (message == "")
            {
                appointment.AppointmentID = (int)newID.Value;
            }
            return message;
        }
        #endregion

        #region Move
        // Moves a booking to a new start time.  The procedure checks the new
        // time is free.
        public static string Move(int appointmentID, DateTime newStartTime)
        {
            return Db.Run("usp_Appointment_Move",
                Db.P("@AppointmentID", appointmentID),
                Db.P("@NewStartTime", newStartTime));
        }
        #endregion

        #region Cancel
        // Cancels a booking.  Returns "" if it worked.
        public static string Cancel(int appointmentID)
        {
            return Db.Run("usp_Appointment_Cancel",
                Db.P("@AppointmentID", appointmentID));
        }
        #endregion

        // Marks a booking as done.
        public static string MarkDone(int appointmentID)
        {
            return Db.Run("usp_Appointment_MarkDone",
                Db.P("@AppointmentID", appointmentID));
        }
    }
}
