﻿using System;
using System.Data;

namespace BikeShop.Data
{
    public static class ReportData
    {
        public static DataTable MechanicWorkload(DateTime fromDate,
            DateTime toDate)
        {
            return Db.GetTable("usp_Report_MechanicWorkload",
                Db.P("@FromDate", fromDate.Date), Db.P("@ToDate", toDate.Date));
        }

        public static DataTable Income(DateTime fromDate, DateTime toDate)
        {
            return Db.GetTable("usp_Report_Income",
                Db.P("@FromDate", fromDate.Date), Db.P("@ToDate", toDate.Date));
        }
    }
}
