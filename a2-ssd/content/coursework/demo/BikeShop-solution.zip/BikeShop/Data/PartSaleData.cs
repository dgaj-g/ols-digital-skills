﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace BikeShop.Data
{
    public static class PartSaleData
    {
        #region Add
        // customerID 0 means a walk-in customer, who is saved as NULL.  The
        // procedure refuses the sale if stock is short.
        // Returns "" if it worked.  The procedure always wants the
        // @NewPartSaleID output parameter, but this screen does not need the
        // number.
        public static string Add(int partID, int customerID, int quantity,
            int soldByStaffID)
        {
            object customer = DBNull.Value;
            if (customerID > 0)
            {
                customer = customerID;
            }
            SqlParameter newID = Db.Out("@NewPartSaleID");
            return Db.Run("usp_PartSale_Add",
                Db.P("@PartID", partID),
                Db.P("@CustomerID", customer),
                Db.P("@Quantity", quantity),
                Db.P("@SoldByStaffID", soldByStaffID),
                newID);
        }
        #endregion

        // Takes a sale back and puts the parts back in stock.
        public static string Refund(int partSaleID)
        {
            return Db.Run("usp_PartSale_Refund",
                Db.P("@PartSaleID", partSaleID));
        }

        // The sales between two dates.
        public static DataTable GetByDateRange(DateTime fromDate,
            DateTime toDate)
        {
            return Db.GetTable("usp_PartSale_GetByDateRange",
                Db.P("@FromDate", fromDate.Date), Db.P("@ToDate", toDate.Date));
        }
    }
}
