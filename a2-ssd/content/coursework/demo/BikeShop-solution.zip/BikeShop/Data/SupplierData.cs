﻿using System.Data;
using System.Data.SqlClient;
using BikeShop.Models;

namespace BikeShop.Data
{
    public static class SupplierData
    {
        // Every supplier.
        public static DataTable GetAll()
        {
            return Db.GetTable("usp_Supplier_GetAll");
        }

        // Saves a new supplier.  Returns "" if it worked, or the sentence to
        // show the user.
        public static string Add(Supplier supplier)
        {
            SqlParameter newID = Db.Out("@NewSupplierID");
            string message = Db.Run("usp_Supplier_Add",
                Db.P("@Name", supplier.Name),
                Db.P("@Phone", supplier.Phone),
                Db.P("@Email", supplier.Email),
                newID);
            if (message == "")
            {
                supplier.SupplierID = (int)newID.Value;
            }
            return message;
        }
    }
}
