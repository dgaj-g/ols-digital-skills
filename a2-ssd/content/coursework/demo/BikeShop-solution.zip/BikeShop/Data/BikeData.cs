﻿using System;
using System.Data;
using System.Data.SqlClient;
using BikeShop.Models;

namespace BikeShop.Data
{
    public static class BikeData
    {
        // purpose = "Hire", "Sale" or null for every bike
        public static DataTable GetAll(string purpose)
        {
            return Db.GetTable("usp_Bike_GetAll", Db.P("@Purpose", purpose));
        }

        #region GetAvailableForHire
        // The hire bikes that are free for every day from startDate to endDate.
        public static DataTable GetAvailableForHire(DateTime startDate,
            DateTime endDate)
        {
            return Db.GetTable("usp_Bike_GetAvailableForHire",
                Db.P("@StartDate", startDate.Date),
                Db.P("@EndDate", endDate.Date));
        }
        #endregion

        // Saves a new bike.  Returns "" if it worked, or the sentence to show
        // the user.
        public static string Add(Bike bike)
        {
            SqlParameter newID = Db.Out("@NewBikeID");
            string message = Db.Run("usp_Bike_Add",
                Db.P("@FrameNumber", bike.FrameNumber),
                Db.P("@Make", bike.Make),
                Db.P("@Model", bike.Model),
                Db.P("@Size", bike.Size),
                Db.P("@Colour", bike.Colour),
                Db.P("@Purpose", bike.Purpose),
                Db.P("@DailyRate", bike.DailyRate),
                Db.P("@SalePrice", bike.SalePrice),
                newID);
            if (message == "")
            {
                bike.BikeID = (int)newID.Value;
            }
            return message;
        }

        #region Lifecycle
        // Reserves a sale bike for a customer.
        public static string Reserve(int bikeID, int customerID)
        {
            return Db.Run("usp_Bike_Reserve", Db.P("@BikeID", bikeID),
                Db.P("@CustomerID", customerID));
        }

        // Puts a reserved bike back on sale.
        public static string Unreserve(int bikeID)
        {
            return Db.Run("usp_Bike_Unreserve", Db.P("@BikeID", bikeID));
        }

        // Sells a bike, once only.
        public static string Sell(int bikeID, int customerID)
        {
            return Db.Run("usp_Bike_Sell", Db.P("@BikeID", bikeID),
                Db.P("@CustomerID", customerID));
        }

        // Marks a bike as in the repair stand (true) or back in the shop
        // (false).
        public static string SetRepair(int bikeID, bool inRepair)
        {
            return Db.Run("usp_Bike_SetRepair", Db.P("@BikeID", bikeID),
                Db.P("@InRepair", inRepair));
        }
        #endregion
    }
}
