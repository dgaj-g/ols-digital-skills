﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace BikeShop.Data
{
    // The ONE place the program talks to SQL Server.  Every method runs a
    // stored procedure.
    // Four things to know:  P makes a parameter.  Out makes an output
    // parameter.
    // GetTable runs a procedure that SELECTs rows.  Run runs a procedure that
    // changes data.
    public static class Db
    {
        #region ConnectionString
        // The connection string lives in App.config, so it can change without
        // touching the code.
        private static string ConnectionString
        {
            get
            {
                ConnectionStringSettingsCollection all =
                    ConfigurationManager.ConnectionStrings;
                return all["BikeShop"].ConnectionString;
            }
        }
        #endregion

        #region P
        // Makes a parameter to send to a procedure.  A C# null becomes a SQL
        // NULL.
        public static SqlParameter P(string name, object value)
        {
            if (value == null)
            {
                value = DBNull.Value;
            }
            return new SqlParameter(name, value);
        }
        #endregion

        #region Out
        // Makes an output parameter: the procedure fills it in, and you read
        // its .Value afterwards.
        public static SqlParameter Out(string name)
        {
            SqlParameter parameter = new SqlParameter(name, SqlDbType.Int);
            parameter.Direction = ParameterDirection.Output;
            return parameter;
        }
        #endregion

        #region GetTable
        // For procedures that SELECT rows.  Fills a DataTable you can put
        // straight into a grid or a combo box.
        public static DataTable GetTable(string procedureName,
            params SqlParameter[] parameters)
        {
            DataTable table = new DataTable();
            using (SqlConnection connection =
                new SqlConnection(ConnectionString))
            using (SqlCommand command = new SqlCommand(procedureName,
                connection))
            {
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddRange(parameters);
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    adapter.Fill(table);
                }
            }
            return table;
        }
        #endregion

        #region Run
        // For procedures that change data.  Adds the @Message output parameter
        // itself and returns
        // whatever the procedure put in it.  "" means it worked.  Anything else
        // is a sentence to
        // show the user.  If SQL Server itself says no (a CHECK or a FOREIGN
        // KEY), that message
        // comes back the same way, so a screen never needs try and catch round
        // a database call.
        public static string Run(string procedureName,
            params SqlParameter[] parameters)
        {
            SqlParameter message = new SqlParameter("@Message",
                SqlDbType.VarChar, 200);
            message.Direction = ParameterDirection.Output;
            try
            {
                using (SqlConnection connection =
                    new SqlConnection(ConnectionString))
                using (SqlCommand command = new SqlCommand(procedureName,
                    connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddRange(parameters);
                    command.Parameters.Add(message);
                    connection.Open();
                    command.ExecuteNonQuery();
                }
            }
            catch (SqlException ex)
            {
                return ex.Message;
            }
            return message.Value.ToString();
        }
        #endregion
    }
}
