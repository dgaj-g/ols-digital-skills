﻿using System.Data;
using System.Data.SqlClient;
using BikeShop.Models;

namespace BikeShop.Data
{
    public static class StaffData
    {
        #region Login
        // Returns one row if the details match an active member of staff,
        // otherwise no rows.
        public static DataTable Login(string username, string password)
        {
            return Db.GetTable("usp_Staff_Login", Db.P("@Username", username),
                Db.P("@Password", password));
        }
        #endregion

        // The staff who are mechanics.
        public static DataTable GetMechanics()
        {
            return Db.GetTable("usp_Staff_GetMechanics");
        }

        // Every member of staff.
        public static DataTable GetAll()
        {
            return Db.GetTable("usp_Staff_GetAll");
        }

        // Saves a new member of staff.  Returns "" if it worked, or the
        // sentence to show the user.
        public static string Add(StaffMember staff)
        {
            SqlParameter newID = Db.Out("@NewStaffID");
            string message = Db.Run("usp_Staff_Add",
                Db.P("@FirstName", staff.FirstName),
                Db.P("@LastName", staff.LastName),
                Db.P("@Role", staff.Role),
                Db.P("@Username", staff.Username),
                Db.P("@Password", staff.Password),
                newID);
            if (message == "")
            {
                staff.StaffID = (int)newID.Value;
            }
            return message;
        }
    }
}
