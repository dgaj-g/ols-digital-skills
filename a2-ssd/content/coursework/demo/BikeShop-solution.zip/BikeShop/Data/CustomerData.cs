﻿using System;
using System.Data;
using System.Data.SqlClient;
using BikeShop.Models;

namespace BikeShop.Data
{
    public static class CustomerData
    {
        #region Search
        // Customers whose name or phone contains the search text.
        public static DataTable Search(string searchText)
        {
            return Db.GetTable("usp_Customer_Search",
                Db.P("@SearchText", searchText));
        }
        #endregion

        #region GetByID
        // One customer as an object, or null if there is no customer with that
        // ID.
        public static Customer GetByID(int customerID)
        {
            DataTable table = Db.GetTable("usp_Customer_GetByID",
                Db.P("@CustomerID", customerID));
            if (table.Rows.Count == 0)
            {
                return null;
            }

            DataRow row = table.Rows[0];
            Customer customer = new Customer();
            customer.CustomerID = (int)row["CustomerID"];
            customer.FirstName = (string)row["FirstName"];
            customer.LastName = (string)row["LastName"];
            customer.Phone = (string)row["Phone"];
            if (row["Email"] == DBNull.Value)
            {
                customer.Email = null;
            }
            else
            {
                customer.Email = (string)row["Email"];
            }
            customer.DateJoined = (DateTime)row["DateJoined"];
            return customer;
        }
        #endregion

        #region Add
        // Saves a new customer.  Returns "" if it worked, or the sentence to
        // show the user.
        public static string Add(Customer customer)
        {
            SqlParameter newID = Db.Out("@NewCustomerID");
            string message = Db.Run("usp_Customer_Add",
                Db.P("@FirstName", customer.FirstName),
                Db.P("@LastName", customer.LastName),
                Db.P("@Phone", customer.Phone),
                Db.P("@Email", customer.Email),
                newID);
            if (message == "")
            {
                customer.CustomerID = (int)newID.Value;
            }
            return message;
        }
        #endregion

        #region Update
        // Saves changes to an existing customer.  Returns "" if it worked.
        public static string Update(Customer customer)
        {
            return Db.Run("usp_Customer_Update",
                Db.P("@CustomerID", customer.CustomerID),
                Db.P("@FirstName", customer.FirstName),
                Db.P("@LastName", customer.LastName),
                Db.P("@Phone", customer.Phone),
                Db.P("@Email", customer.Email));
        }
        #endregion

        #region Delete
        // The procedure refuses if the customer has bookings.  Returns "" if it
        // worked.
        public static string Delete(int customerID)
        {
            return Db.Run("usp_Customer_Delete",
                Db.P("@CustomerID", customerID));
        }
        #endregion
    }
}
