﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace BikeShop.Data
{
    public static class PartOrderData
    {
        // Orders more of a part from its supplier.  Returns "" if it worked.
        // The procedure always wants the @NewPartOrderID output parameter, but
        // this screen does not need the number.
        public static string Place(int partID, int qtyOrdered,
            DateTime expectedOn, int placedByStaffID)
        {
            SqlParameter newID = Db.Out("@NewPartOrderID");
            return Db.Run("usp_PartOrder_Place",
                Db.P("@PartID", partID),
                Db.P("@QtyOrdered", qtyOrdered),
                Db.P("@ExpectedOn", expectedOn.Date),
                Db.P("@PlacedByStaffID", placedByStaffID),
                newID);
        }

        #region Receive
        // One call: the order closes AND the stock goes up.
        public static string Receive(int partOrderID, int qtyReceived)
        {
            return Db.Run("usp_PartOrder_Receive",
                Db.P("@PartOrderID", partOrderID),
                Db.P("@QtyReceived", qtyReceived));
        }
        #endregion

        // Cancels an order that has not arrived.
        public static string Cancel(int partOrderID)
        {
            return Db.Run("usp_PartOrder_Cancel",
                Db.P("@PartOrderID", partOrderID));
        }

        // The orders still waiting for a delivery.
        public static DataTable GetOpen()
        {
            return Db.GetTable("usp_PartOrder_GetOpen");
        }

        // Every order, open or closed.
        public static DataTable GetAll()
        {
            return Db.GetTable("usp_PartOrder_GetAll");
        }
    }
}
