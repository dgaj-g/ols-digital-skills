﻿using System.Data;
using System.Data.SqlClient;
using BikeShop.Models;

namespace BikeShop.Data
{
    public static class PartData
    {
        // Every part.
        public static DataTable GetAll()
        {
            return Db.GetTable("usp_Part_GetAll");
        }

        #region GetReorderList
        // The parts whose stock has fallen to the reorder level or below.
        public static DataTable GetReorderList()
        {
            return Db.GetTable("usp_Part_GetReorderList");
        }
        #endregion

        // Saves a new part.  Returns "" if it worked, or the sentence to show
        // the user.
        public static string Add(Part part)
        {
            SqlParameter newID = Db.Out("@NewPartID");
            string message = Db.Run("usp_Part_Add",
                Db.P("@PartCode", part.PartCode),
                Db.P("@Name", part.Name),
                Db.P("@SupplierID", part.SupplierID),
                Db.P("@UnitCost", part.UnitCost),
                Db.P("@SellPrice", part.SellPrice),
                Db.P("@QtyInStock", part.QtyInStock),
                Db.P("@ReorderLevel", part.ReorderLevel),
                Db.P("@ReorderQty", part.ReorderQty),
                newID);
            if (message == "")
            {
                part.PartID = (int)newID.Value;
            }
            return message;
        }

        // No QtyInStock here: stock only changes through sales, deliveries and
        // refunds.
        public static string Update(Part part)
        {
            return Db.Run("usp_Part_Update",
                Db.P("@PartID", part.PartID),
                Db.P("@Name", part.Name),
                Db.P("@SupplierID", part.SupplierID),
                Db.P("@UnitCost", part.UnitCost),
                Db.P("@SellPrice", part.SellPrice),
                Db.P("@ReorderLevel", part.ReorderLevel),
                Db.P("@ReorderQty", part.ReorderQty));
        }
    }
}
