﻿using System.Windows.Forms;

namespace BikeShop
{
    // Three kinds of message box, so every form says things the same way.
    public static class Msg
    {
        private const string Title = "Towpath Cycles";

        public static void Info(string text)
        {
            MessageBox.Show(text, Title, MessageBoxButtons.OK,
                MessageBoxIcon.Information);
        }

        public static void Problem(string text)
        {
            MessageBox.Show(text, Title, MessageBoxButtons.OK,
                MessageBoxIcon.Warning);
        }

        // Returns true when the user clicks Yes.
        public static bool Ask(string question)
        {
            return MessageBox.Show(question, Title, MessageBoxButtons.YesNo,
                MessageBoxIcon.Question) == DialogResult.Yes;
        }
    }
}
