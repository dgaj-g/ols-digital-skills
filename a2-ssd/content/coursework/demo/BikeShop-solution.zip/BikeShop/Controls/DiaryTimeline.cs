﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Drawing.Text;
using System.Windows.Forms;

namespace BikeShop.Controls
{
    // Raised when the user clicks a booking block.
    public class BookingPickedEventArgs : EventArgs
    {
        public int AppointmentID { get; set; }
    }

    // A picture of one day: a row for each mechanic, 08:30 to 17:30 across,
    // each booking as a block.
    // Optional in the coursework: the grid already shows everything.  Drag it
    // from the Toolbox after one build.
    public class DiaryTimeline : Panel
    {
        private const int LabelWidth = 110;
        private const int RowHeight = 44;
        private const int HeaderHeight = 22;
        private static readonly TimeSpan DayStart = new TimeSpan(8, 30, 0);
        private static readonly TimeSpan DayEnd = new TimeSpan(17, 30, 0);

        private class Block
        {
            public Rectangle Area;
            public int AppointmentID;
            public string Text;
            public string Status;
        }

        private readonly List<string> lanes = new List<string>();
        private readonly List<Block> blocks = new List<Block>();
        private int highlighted;
        private DateTime day;

        public event EventHandler<BookingPickedEventArgs> BookingPicked;

        public DiaryTimeline()
        {
            DoubleBuffered = true;        // no flicker when it repaints
            BackColor = Color.White;
            BorderStyle = BorderStyle.FixedSingle;
            Cursor = Cursors.Hand;
        }

        #region ShowDay
        // Takes the same table the grid shows (usp_Appointment_GetByDay) and
        // lays the blocks out.
        public void ShowDay(DateTime whichDay, DataTable bookings)
        {
            day = whichDay.Date;
            lanes.Clear();
            blocks.Clear();

            foreach (DataRow row in bookings.Rows)
            {
                string mechanic = Convert.ToString(row["Mechanic"]);
                if (!lanes.Contains(mechanic)) lanes.Add(mechanic);
            }
            lanes.Sort();

            foreach (DataRow row in bookings.Rows)
            {
                string status = Convert.ToString(row["Status"]);
                // a cancelled booking frees the time, so it is not drawn
                if (status == "Cancelled") continue;

                Block block = new Block();
                block.AppointmentID = Convert.ToInt32(row["AppointmentID"]);
                block.Status = status;
                block.Text = Convert.ToString(row["Customer"]) + " · "
                    + Convert.ToString(row["Service"]);
                int lane = lanes.IndexOf(Convert.ToString(row["Mechanic"]));
                int x1 = XFor(Convert.ToDateTime(row["StartTime"]).TimeOfDay);
                int x2 = XFor(Convert.ToDateTime(row["EndTime"]).TimeOfDay);
                block.Area = new Rectangle(x1, HeaderHeight + lane * RowHeight
                    + 6, Math.Max(x2 - x1 - 2, 6), RowHeight - 12);
                blocks.Add(block);
            }
            Invalidate();
        }

        public void Highlight(int appointmentID)
        {
            highlighted = appointmentID;
            Invalidate();
        }
        #endregion

        // Where a time falls across the control: 08:30 at the left edge of the
        // lanes, 17:30 at the right.
        private int XFor(TimeSpan time)
        {
            double minutesIn = (time - DayStart).TotalMinutes;
            double minutesAll = (DayEnd - DayStart).TotalMinutes;
            double fraction = minutesIn / minutesAll;
            fraction = Math.Max(0, Math.Min(1, fraction));
            return LabelWidth
                + (int)Math.Round(fraction * (Width - LabelWidth - 10));
        }

        #region Paint
        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            Graphics g = e.Graphics;
            g.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;

            using (Font small = new Font(Font.FontFamily, 8f))
            using (Pen hairline = new Pen(Color.FromArgb(220, 224, 230)))
            using (Brush grey = new SolidBrush(Color.FromArgb(92, 103, 116)))
            {
                // hour lines and labels
                for (TimeSpan t = new TimeSpan(9, 0, 0); t < DayEnd;
                    t = t.Add(TimeSpan.FromHours(1)))
                {
                    int x = XFor(t);
                    g.DrawLine(hairline, x, HeaderHeight, x, Height);
                    g.DrawString(t.ToString(@"hh\:mm"), small, grey, x - 16, 4);
                }
                // mechanic names
                for (int i = 0; i < lanes.Count; i++)
                {
                    int y = HeaderHeight + i * RowHeight;
                    g.DrawLine(hairline, 0, y, Width, y);
                    g.DrawString(lanes[i], Font, Brushes.Black, 8, y + 12);
                }
                if (lanes.Count == 0)
                {
                    string when = day.ToString("dddd d MMMM");
                    string none = "No bookings on " + when;
                    int y = HeaderHeight + 14;
                    g.DrawString(none, Font, grey, LabelWidth, y);
                }
            }

            foreach (Block block in blocks)
            {
                Color fill = Color.FromArgb(79, 163, 227);
                if (block.Status == "Done")
                {
                    fill = Color.FromArgb(63, 185, 80);
                }
                using (Brush brush = new SolidBrush(fill))
                    g.FillRectangle(brush, block.Area);
                if (block.AppointmentID == highlighted)
                    using (Pen ring = new Pen(Color.FromArgb(228, 184, 36), 3))
                        g.DrawRectangle(ring, block.Area);

                Rectangle textArea = block.Area;
                textArea.Inflate(-4, -2);
                TextFormatFlags flags = TextFormatFlags.EndEllipsis
                    | TextFormatFlags.VerticalCenter
                    | TextFormatFlags.NoPadding;
                TextRenderer.DrawText(g, block.Text, Font, textArea,
                    Color.White, flags);
            }
        }

        protected override void OnResize(EventArgs eventargs)
        {
            base.OnResize(eventargs);
            Invalidate();
        }
        #endregion

        #region Click
        protected override void OnMouseClick(MouseEventArgs e)
        {
            base.OnMouseClick(e);
            foreach (Block block in blocks)
            {
                if (block.Area.Contains(e.Location))
                {
                    BookingPickedEventArgs args = new BookingPickedEventArgs();
                    args.AppointmentID = block.AppointmentID;
                    if (BookingPicked != null)
                    {
                        BookingPicked(this, args);
                    }
                    return;
                }
            }
        }
        #endregion
    }
}
