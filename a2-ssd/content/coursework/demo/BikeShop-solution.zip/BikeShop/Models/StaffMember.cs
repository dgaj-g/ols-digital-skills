﻿namespace BikeShop.Models
{
    // One member of staff.  Plain properties only.
    public class StaffMember
    {
        public int StaffID { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Role { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
    }
}
