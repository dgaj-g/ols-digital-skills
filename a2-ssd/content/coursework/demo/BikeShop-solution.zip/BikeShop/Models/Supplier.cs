﻿namespace BikeShop.Models
{
    // One supplier of parts.  Plain properties only.
    public class Supplier
    {
        public int SupplierID { get; set; }
        public string Name { get; set; }
        public string Phone { get; set; }
        public string Email { get; set; }
    }
}
