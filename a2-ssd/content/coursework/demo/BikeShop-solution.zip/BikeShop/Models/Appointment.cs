﻿using System;

namespace BikeShop.Models
{
    // One service booking.  Plain properties only: the form checks the values,
    // and the procedure checks the clash.
    public class Appointment
    {
        public int AppointmentID { get; set; }
        public int CustomerID { get; set; }
        public int MechanicID { get; set; }
        public int ServiceTypeID { get; set; }
        public DateTime StartTime { get; set; }
        public string BikeDescription { get; set; }
        public string Notes { get; set; }
        public int BookedByStaffID { get; set; }
    }
}
