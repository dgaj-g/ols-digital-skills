﻿namespace BikeShop.Models
{
    // One part we stock.  Plain properties only.
    public class Part
    {
        public int PartID { get; set; }
        public string PartCode { get; set; }
        public string Name { get; set; }
        public int SupplierID { get; set; }
        public decimal UnitCost { get; set; }
        public decimal SellPrice { get; set; }
        public int QtyInStock { get; set; }
        public int ReorderLevel { get; set; }
        public int ReorderQty { get; set; }
    }
}
