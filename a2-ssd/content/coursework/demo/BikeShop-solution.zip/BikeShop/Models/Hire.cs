﻿using System;

namespace BikeShop.Models
{
    // One bike hire.  Plain properties only: the form checks the dates and the
    // deposit.
    public class Hire
    {
        public int HireID { get; set; }
        public int BikeID { get; set; }
        public int CustomerID { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public decimal DepositPaid { get; set; }
        public int BookedByStaffID { get; set; }

        public int Days
        {
            get { return (EndDate - StartDate).Days; }
        }
    }
}
