﻿using System;

namespace BikeShop.Models
{
    // One customer.  Plain properties only: the form checks what the user typed
    // before it fills these in.
    public class Customer
    {
        public int CustomerID { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Phone { get; set; }
        public string Email { get; set; }
        public DateTime DateJoined { get; set; }

        public string FullName
        {
            get { return FirstName + " " + LastName; }
        }
    }
}
