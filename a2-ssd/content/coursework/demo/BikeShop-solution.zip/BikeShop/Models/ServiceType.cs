﻿namespace BikeShop.Models
{
    // One kind of service, such as a puncture repair.  Plain properties only.
    public class ServiceType
    {
        public int ServiceTypeID { get; set; }
        public string Name { get; set; }
        public int DurationMinutes { get; set; }
        public decimal Price { get; set; }
    }
}
