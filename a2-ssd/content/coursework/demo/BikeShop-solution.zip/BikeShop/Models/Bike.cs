﻿namespace BikeShop.Models
{
    // One bike, for hire or for sale.  Plain properties only.  The price that
    // does not apply is null.
    public class Bike
    {
        public int BikeID { get; set; }
        public string FrameNumber { get; set; }
        public string Make { get; set; }
        public string Model { get; set; }
        public string Size { get; set; }
        public string Colour { get; set; }
        public string Purpose { get; set; }
        public decimal? DailyRate { get; set; }
        public decimal? SalePrice { get; set; }
    }
}
